#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "funcoes_fornecidas.h"
#include "lista.h"

//Trabalho Prático 1 - Organização de Arquivos
//Alunos: Gabriel Hyppolito - 14571810, Juan Marques Jordão - 14758742

//definicao das structs de registro e cabecalho segundo especificado
typedef struct{
    char status;
    long int topo, proxByteOffset;
    int nroRegArq, nroRegRem;
}Cabecalho;

typedef struct{
    int id, idade, tamanhoRegistro, tamNomeJog, tamNacionalidade, tamNomeClube;
    long int Prox;
    char removido, *nomeJogador, *nacionalidade, *nomeClube;
}Registro;

typedef struct{
    char status;
}CabecalhoIndex;

typedef struct{
    int id;
    long int byteoffset;
}RegistroIndex;

//funcao para testar se o arquivo foi aberto corretamente
bool abreArquivo(FILE *arquivo){
    if(arquivo == NULL){
        printf("Falha no processamento do arquivo.\n");
        return false;
    }
    return true;
}

//funcao chamada para definir o estado inicial do cabeçalho
void inicializarCabecalho(Cabecalho *cabecalho){
    cabecalho->status = '0';
    cabecalho->topo = -1;
    cabecalho->proxByteOffset = 0;
    cabecalho->nroRegArq = 0;
    cabecalho->nroRegRem = 0;
}

//funcao chamada para escrita do cabecalho no arquivo de saida
void escreverCabecalho(Cabecalho *cabecalho, FILE *arquivo){
    fwrite(&cabecalho->status, sizeof(char), 1, arquivo);
    fwrite(&cabecalho->topo, sizeof(long int), 1, arquivo);
    fwrite(&cabecalho->proxByteOffset, sizeof(long int), 1, arquivo);
    fwrite(&cabecalho->nroRegArq, sizeof(int), 1, arquivo);
    fwrite(&cabecalho->nroRegRem, sizeof(int), 1, arquivo);
}

//funcao usada para leitura do cabecalho de um arquivo binario recebido e salva-lo na memoria principal para uso
void lerCabecalho(Cabecalho *cabecalho, FILE *arquivo){
    fread(&cabecalho->status, sizeof(char), 1, arquivo);
    fread(&cabecalho->topo, sizeof(long int), 1, arquivo);
    fread(&cabecalho->proxByteOffset, sizeof(long int), 1, arquivo);
    fread(&cabecalho->nroRegArq, sizeof(int), 1, arquivo);
    fread(&cabecalho->nroRegRem, sizeof(int), 1, arquivo);
}

//funcao usada pra ler campos de um arquivo binario recebido e salva-los na mem. principal para uso
void lerRegistro(Registro *registro, FILE *arquivo, int filtro){
            
    //filtro -> flag para indicar se eh necessaria leitura campos removido e tamanhoRegistro ou nao
    if(filtro == 1){
        fread(&registro->removido, sizeof(char), 1, arquivo);
        fread(&registro->tamanhoRegistro, sizeof(int), 1, arquivo);
        fread(&registro->Prox, sizeof(long int), 1, arquivo);
        fread(&registro->id, sizeof(int), 1, arquivo);
        fread(&registro->idade, sizeof(int), 1, arquivo);
        fread(&registro->tamNomeJog, sizeof(int), 1, arquivo);
        registro->nomeJogador = (char *)malloc((registro->tamNomeJog+1) * sizeof(char));
        fread(registro->nomeJogador, sizeof(char), registro->tamNomeJog, arquivo);
        fread(&registro->tamNacionalidade, sizeof(int), 1, arquivo);
        registro->nacionalidade = (char *)malloc((registro->tamNacionalidade+1) * sizeof(char));
        fread(registro->nacionalidade, sizeof(char), registro->tamNacionalidade, arquivo);
        fread(&registro->tamNomeClube, sizeof(int), 1, arquivo);
        registro->nomeClube = (char *)malloc((registro->tamNomeClube+1) * sizeof(char));
        fread(registro->nomeClube, sizeof(char), registro->tamNomeClube, arquivo);
    }else{
        fread(&registro->Prox, sizeof(long int), 1, arquivo);
        fread(&registro->id, sizeof(int), 1, arquivo);
        fread(&registro->idade, sizeof(int), 1, arquivo);
        fread(&registro->tamNomeJog, sizeof(int), 1, arquivo);
        registro->nomeJogador = (char *)malloc((registro->tamNomeJog+1) * sizeof(char));
        fread(registro->nomeJogador, sizeof(char), registro->tamNomeJog, arquivo);
        registro->nomeJogador[registro->tamNomeJog] = '\0';
        fread(&registro->tamNacionalidade, sizeof(int), 1, arquivo);
        registro->nacionalidade = (char *)malloc((registro->tamNacionalidade+1) * sizeof(char));
        fread(registro->nacionalidade, sizeof(char), registro->tamNacionalidade, arquivo);
        registro->nacionalidade[registro->tamNacionalidade] = '\0';
        fread(&registro->tamNomeClube, sizeof(int), 1, arquivo);
        registro->nomeClube = (char *)malloc((registro->tamNomeClube+1) * sizeof(char));
        fread(registro->nomeClube, sizeof(char), registro->tamNomeClube, arquivo);
        registro->nomeClube[registro->tamNomeClube] = '\0';
    }
}

//funcao usada para escrever um registro salvo na memoria principal no arquivo de saida, campo a campo
void escreverRegistro(Registro *registro, FILE *arquivo){
    fwrite(&registro->removido, sizeof(char), 1, arquivo);
    fwrite(&registro->tamanhoRegistro, sizeof(int), 1, arquivo);
    fwrite(&registro->Prox, sizeof(long int), 1, arquivo);
    fwrite(&registro->id, sizeof(int), 1, arquivo);
    fwrite(&registro->idade, sizeof(int), 1, arquivo);
    fwrite(&registro->tamNomeJog, sizeof(int), 1, arquivo);
    if(registro->tamNomeJog != 0)
        fwrite(registro->nomeJogador, registro->tamNomeJog, 1, arquivo);
    fwrite(&registro->tamNacionalidade, sizeof(int), 1, arquivo);
    if(registro->tamNacionalidade != 0)
        fwrite(registro->nacionalidade, registro->tamNacionalidade, 1, arquivo);
    fwrite(&registro->tamNomeClube, sizeof(int), 1, arquivo);
    if(registro->tamNomeClube != 0)
        fwrite(registro->nomeClube, registro->tamNomeClube, 1, arquivo);
}

//inicializa registro a ser adicionado com os campos lidos
void inicializaRegistro(Registro *registro, int id, int idade, int tamNomeJog, char *nomeJog, int tamNacionalidade, char *nacionalidade, int tamNomeClube, char *nomeClube){
    registro->removido = '0';
    registro->Prox = -1;
    registro->id = id;
    registro->idade = idade;
    registro->tamNomeJog = tamNomeJog;
    if(tamNomeJog == 0)
        registro->nomeJogador = NULL;
    else{
        registro->nomeJogador = (char *)malloc((tamNomeJog+1) * sizeof(char));
        strcpy(registro->nomeJogador, nomeJog);
    }
    registro->tamNacionalidade = tamNacionalidade;
    if(tamNacionalidade == 0)
        registro->nacionalidade = NULL;
    else{
        registro->nacionalidade = (char *)malloc((tamNacionalidade+1) * sizeof(char));
        strcpy(registro->nacionalidade, nacionalidade);
    }
    registro->tamNomeClube = tamNomeClube;
    if(tamNomeClube == 0)
        registro->nomeClube = NULL;
    else{
        registro->nomeClube = (char *)malloc((tamNomeClube+1) * sizeof(char));
        strcpy(registro->nomeClube, nomeClube);
    }

}

//funcao para preencher os campos id e idade do registro a partir da string obtida pela 
//logica de leitura dos dados do arquivo de entrada
int preencheCampoFixo(char *campo){
    if(strlen(campo) == 0)
        return -1;
    else
        return atoi(campo);
}

//funcao que le o status do arquivo e retorna se o arquivo esta consistente ou nao
bool trataStatus(FILE *arquivo){
    char status;
    fread(&status, sizeof(char), 1, arquivo);
    if(status == '0'){
        printf("Falha no processamento do arquivo.\n");
        return false;
    }
    return true;
}

void inserirIndice(RegistroIndex *indice, int *cont, RegistroIndex aux){
    int i = *cont - 1;
    while (i>=0 && indice[i].id > aux.id){
        indice[i+1] = indice[i];
        i--;
    }
    indice[i + 1] = aux;
    (*cont)++;
}

void escreveIndex(FILE *arqIndex, RegistroIndex *indice, int cont){
    for(int i=0; i<cont; i++){
        fwrite(&indice[i].id, sizeof(int), 1, arqIndex);
        fwrite(&indice[i].byteoffset, sizeof(long int), 1, arqIndex);
    }
}

//funcao que libera a memoria alocada para os campos de tamanho variavel do registro
void freeRegistro(Registro *registro){
     registro->nomeClube = NULL;
     registro->nacionalidade = NULL;
     registro->nomeJogador = NULL;
     free(registro->nomeClube);
     free(registro->nacionalidade);
     free(registro->nomeJogador);
}

void leIndice(RegistroIndex *indice, FILE *arqindex, CabecalhoIndex cabecalho, int *cont){
    fseek(arqindex, 0, SEEK_SET);
    fread(&cabecalho.status, sizeof(char), 1, arqindex);
    while(fread(&indice[*cont].id, sizeof(int), 1, arqindex) == 1){
        fread(&indice[*cont].byteoffset, sizeof(long int), 1, arqindex);
        (*cont)++;
    }
}

//funcao da leitura de dados de um arquivo inicial e escrita dos mesmos em um arquivo binario
//le linhas do arquivo de entrada e as separa em campos, que sao salvos no registro e escritos no arquivo de saida
void createTable(char *entrada, char *saida){
    
    //tentativa de abertura dos nomes dos arquivos recebidos como parametro e saida em caso de erro
    FILE *arquivoEntrada = fopen(entrada, "r");
    if(!abreArquivo(arquivoEntrada))
        return;
    FILE *arquivoSaida = fopen(saida, "wb");
    if(!abreArquivo(arquivoSaida)){
        fclose(arquivoEntrada);
        return;
    }

    //declaracao do registro e cabecalho, com inicializacao e escrita do ultimo no arquivo de saida
    Cabecalho cabecalho;
    Registro registro;
    inicializarCabecalho(&cabecalho);
    escreverCabecalho(&cabecalho, arquivoSaida);

    //limpar primeira linha inutilizavel pro código
    char buffer[45];
    fread(buffer, sizeof(char), 45, arquivoEntrada);

    //variavel teste para armazenar campos e linha para armazenar a linha do arquivo de entrada
    char teste[300], linha[300];

    //loop-while para ler cada linha do arquivo de entrada, extraindo os campos para o registro
    while (fgets(linha, sizeof(linha), arquivoEntrada) != NULL){
        int i=0, j=0;//variaveis para percorrer a linha lida e extrair os campos

        //extraindo o id do jogador
        //armazena o que foi lido da linha em um vet auxiliar ate encontrar uma virgula
        while(linha[i] != ','){
            teste[j] = linha[i];
            i++;
            j++;
        }
        //finaliza a string auxiliar, faz o tratamento do campo lido e salva no registro e pula a virgula e reseta indice do vet aux
        teste[j] = '\0'; 
        registro.id = preencheCampoFixo(teste);
        i++; j=0;

        //extraindo a idade do jogador
        while(linha[i] != ','){
            teste[j] = linha[i];
            i++;
            j++;
        }
        teste[j] = '\0';
        registro.idade = preencheCampoFixo(teste);
        i++; j=0;
        
        //extraindo o nome do jogador
        //nos campos de tam variavel, salva-se o tamcampo e caso nao zero,
        //aloca-se memoria e copia-se o campo pro registro
        while(linha[i] != ','){
            teste[j] = linha[i];
            i++;
            j++;
        }
        teste[j] = '\0';
        registro.tamNomeJog = strlen(teste); 
        if(registro.tamNomeJog == 0){
            registro.nomeJogador = NULL;
        }else{
            registro.nomeJogador = (char *)malloc((registro.tamNomeJog+1) * sizeof(char));
            strcpy(registro.nomeJogador, teste);
        }
        i++; j=0;

        //extraindo a nacionalidade do jogador
        while(linha[i] != ','){
            teste[j] = linha[i];
            i++;
            j++;
        }
        teste[j] = '\0';
        registro.tamNacionalidade = strlen(teste);
        if(registro.tamNacionalidade == 0){
            registro.nacionalidade = NULL;
        }else{
            registro.nacionalidade = (char *)malloc((registro.tamNacionalidade+1) * sizeof(char));
            strcpy(registro.nacionalidade, teste);
        }
        i++; j=0;

        //extraindo o nome do clube do jogador
        //como ultimo campo, le ate final da linha
        while(linha[i] != '\n'){
            teste[j] = linha[i];
            j++;
            i++;
        }
        teste[j] = '\0';
        registro.tamNomeClube = strlen(teste);
        if(registro.tamNomeClube == 0){
            registro.nomeClube = NULL;
        }else{
            registro.nomeClube = (char *)malloc((registro.tamNomeClube+1) * sizeof(char));
            strcpy(registro.nomeClube, teste);
        }
        
        //inicializacao campos registro
        registro.removido = '0';
        registro.Prox = -1;
        registro.tamanhoRegistro = sizeof(int)*6 + sizeof(long int) + sizeof(char)*(registro.tamNomeJog + registro.tamNacionalidade + registro.tamNomeClube + 1);
        
        //escrita do registro lido no arquivo de saida
        escreverRegistro(&registro, arquivoSaida);
        cabecalho.nroRegArq++; //incrementa o numero de registros no arquivo

        //liberando memoria alocada para os campos variaveis
        freeRegistro(&registro);
    }

    //ATUALIZA CABECALHO
    cabecalho.status = '1';
    cabecalho.proxByteOffset = ftell(arquivoSaida); //prox disponivel = prox byte do ultimo campo escrito
    fseek(arquivoSaida, 0, SEEK_SET); //volta pro inicio do arquivo de saida
    escreverCabecalho(&cabecalho, arquivoSaida); //escreve o cabecalho atualizado

    //fecha arquivos usados e chama a funcao binarioNaTela
    fclose(arquivoEntrada);
    fclose(arquivoSaida);
    binarioNaTela(saida);
}

//funcao para leitura de registros de um arquivo binario e impressao dos campos na tela
//abre o arquivo, pega o total de registros e imprime as informacoes principais de cada reg nao removido
void selectFrom(char* arq){
    
    //tentativa de abertura do arquivo binario e retorno em caso de erro
    FILE *arquivo;
    arquivo = fopen(arq, "rb");
    if(!abreArquivo(arquivo))
        return;
    if(!trataStatus(arquivo)){
        fclose(arquivo);
        return;
    }

    //le cabecalho para pegar valores de numero de registros armazenados e removidos
    fseek(arquivo, 0, SEEK_SET);
    Cabecalho cabecalho;
    lerCabecalho(&cabecalho, arquivo);

    //declara registro
    Registro registro;
    //loop para leitura de todos os registros
    for(int i=0; i < cabecalho.nroRegArq+cabecalho.nroRegRem; i++){
        //leitura dos campos 'removido' e 'tamanhoRegistro'
        fread(&registro.removido, sizeof(char), 1, arquivo);
        fread(&registro.tamanhoRegistro, sizeof(int), 1, arquivo);
        if(registro.removido == '0'){ //se nao foi removido
            //traz registro pra memoria principal
            lerRegistro(&registro, arquivo, 0);      

            //impressao dos campos do registro
            //uso de operador ternario para facilitar impressao, se tamCampo = 0, imprime "SEM DADO"
            printf("Nome do Jogador: %s\n", registro.tamNomeJog ? registro.nomeJogador : "SEM DADO");
            printf("Nacionalidade do Jogador: %s\n", registro.tamNacionalidade ? registro.nacionalidade : "SEM DADO");
            printf("Clube do Jogador: %s\n", registro.tamNomeClube ? registro.nomeClube : "SEM DADO");
            printf("\n");

            //libera a memoria alocada para os campos variaveis
            freeRegistro(&registro);
        }else{
            //caso esteja removido, pula para o proximo usando o tamanho do registro
            fseek(arquivo, registro.tamanhoRegistro-5, SEEK_CUR);
        }
    }
    fclose(arquivo);
}

//funcao que realiza uma quantidade n de buscas com parametros especificos no arquivo binario recebido
void selectWhere(char* arqBin, int n) {
    FILE* arquivo = fopen(arqBin, "rb");
    if(!abreArquivo(arquivo))
        return;
    if(!trataStatus(arquivo)){
        fclose(arquivo);
        return;
    }

    //loop para realizar n buscas
    for (int i = 0; i < n; i++) {
        printf("Busca %d\n\n", (i + 1));
        
        //inicializacao de variaveis, garantindo reset de valores a cada busca
        int id = -1, idade = -1, parametros = 0, achou = 0;
        //parametros = numero de parametros da busca, achou = flag para indicar se algum registro foi encontrado
        char nomeJogador[30] = "", nacionalidade[30] = "", nomeClube[30] = "";
        
        //leitura dos parametros de busca
        scanf("%d", &parametros); 
        for (int j = 0; j < parametros; j++) {
            char busca[255];
            scanf("%s", busca);
            if (strcmp(busca, "id") == 0) {
                scanf("%d", &id);
            } else if (strcmp(busca, "idade") == 0) {
                scanf("%d", &idade);
            } else if (strcmp(busca, "nomeJogador") == 0) {
                scan_quote_string(nomeJogador);
            } else if (strcmp(busca, "nacionalidade") == 0) {
                scan_quote_string(nacionalidade);
            } else if (strcmp(busca, "nomeClube") == 0) {
                scan_quote_string(nomeClube);
            }
        }

        //tenta abrir o arquivo e pula para a ler a quantidade de registros armazenados e removidos no arquivo
        //le cabecalho para pegar valores de numero de registros armazenados e removidos
        fseek(arquivo, 0, SEEK_SET);
        Cabecalho cabecalho;
        lerCabecalho(&cabecalho, arquivo);

        Registro registro; 
        for(int i=0; i<cabecalho.nroRegArq+cabecalho.nroRegRem; i++) {
            //loop para ler todos registros ate fim do arquivo
            lerRegistro(&registro, arquivo, 1);

            int valido = 1; //flag para verificar se o registro atende aos parametros de busca

            //cadeia de if's para comparar o registro atual com os parametros
            if (id != -1 && registro.id != id)
                valido = 0;
            if (idade != -1 && registro.idade != idade)
                valido = 0; 
            if (strcmp(nomeJogador, "") != 0 && strcmp(registro.nomeJogador, nomeJogador) != 0)
                valido = 0;
            if (strcmp(nacionalidade, "") != 0 && strcmp(registro.nacionalidade, nacionalidade) != 0)
                valido = 0;
            if (strcmp(nomeClube, "") != 0 && strcmp(registro.nomeClube, nomeClube) != 0)
                valido = 0;

            //se o registro atende parametros e nao esta removido
            if (valido == 1 && registro.removido != '1') {
                printf("Nome do Jogador: %s\n", registro.tamNomeJog ? registro.nomeJogador : "SEM DADO");
                printf("Nacionalidade do Jogador: %s\n", registro.tamNacionalidade ? registro.nacionalidade : "SEM DADO");
                printf("Clube do Jogador: %s\n", registro.tamNomeClube ? registro.nomeClube : "SEM DADO");
                printf("\n");
                achou = 1; //flag para indicar que pelo menos um registro foi encontrado

                //se id foi parametro de busca, nao ha necessidade de continuar
                if(id != -1){
                    break;
                }
            }
            freeRegistro(&registro);//libera memoria alocada para os campos variaveis
        }
        
        //se nenhum registro foi encontrado, imprime a mensagem de erro
        if (achou == 0) {
            printf("Registro inexistente.\n\n");
        }
    }

    fclose(arquivo); 
}

int createIndex(char *nomedados, char *nomeindex){
    FILE *arqDados = fopen(nomedados, "rb");
    if(!abreArquivo(arqDados))
        return 0;
    if(!trataStatus(arqDados)){
        fclose(arqDados);
        return 0;
    }
    FILE *arqIndex = fopen(nomeindex, "wb");
    if(!abreArquivo(arqIndex)){
        fclose(arqDados);
        fclose(arqIndex);
        return 0;
    }

    fseek(arqDados, 0, SEEK_SET);
    Cabecalho cabecalho;
    lerCabecalho(&cabecalho, arqDados);

    CabecalhoIndex cabecalhoIndex;
    cabecalhoIndex.status = '0';
    fwrite(&cabecalhoIndex.status, sizeof(char), 1, arqIndex);

    Registro registro;
    RegistroIndex *indice = (RegistroIndex *)malloc(sizeof(RegistroIndex) * cabecalho.nroRegArq);
    RegistroIndex aux;
    int cont = 0;

    //define o offset inicial após o cabeçalho
    long int offset = ftell(arqDados);

    //loop para ler todos os registros
    for(int i = 0; i < cabecalho.nroRegArq + cabecalho.nroRegRem; i++){
        fread(&registro.removido, sizeof(char), 1, arqDados);
        fread(&registro.tamanhoRegistro, sizeof(int), 1, arqDados);

        offset = ftell(arqDados) - sizeof(char) - sizeof(int);

        if(registro.removido == '0'){
            lerRegistro(&registro, arqDados, 0);
            aux.id = registro.id;
            aux.byteoffset = offset;
            inserirIndice(indice, &cont, aux);

            long int finalOffset = offset + registro.tamanhoRegistro;
            fseek(arqDados, finalOffset, SEEK_SET);
        } else {
            fseek(arqDados, registro.tamanhoRegistro - (sizeof(char) + sizeof(int)), SEEK_CUR);
        }

        freeRegistro(&registro);
    }

    escreveIndex(arqIndex, indice, cont);

    cabecalhoIndex.status = '1';
    fseek(arqIndex, 0, SEEK_SET);
    fwrite(&cabecalhoIndex.status, sizeof(char), 1, arqIndex);

    fclose(arqDados);
    fclose(arqIndex);
    free(indice);

    return 1;
}


int deleteWhere(char *arq, char *index, int n){
    FILE *arqDados = fopen(arq, "r+b");
    if(!abreArquivo(arqDados))
        return 0;
    if(!trataStatus(arqDados)){
        fclose(arqDados);
        return 0;
    }

    //abre o arquivo de indice e chama a funcao de criacao do indice
    FILE *arqIndex = fopen(index, "w+b");
    if(!abreArquivo(arqIndex)){
        fclose(arqDados);
        return 0;
    }
    createIndex(arq, index);

     // Criar um novo arquivo temporário para o índice
    FILE *tmpIndex = fopen("temp_index.bin", "wb");
    if (!abreArquivo(tmpIndex)) {
        fclose(arqDados);
        fclose(arqIndex);
        return 0;
    }
    
    Cabecalho cabecalho;
    fseek(arqDados, 0, SEEK_SET);
    lerCabecalho(&cabecalho, arqDados);
    cabecalho.status = '0';

    //traz o arquivo de indice para a memoria principal
    CabecalhoIndex cabecalhoIndex;
    RegistroIndex *indice = (RegistroIndex *)malloc(sizeof(RegistroIndex)*cabecalho.nroRegArq);
    int cont=0;
    leIndice(indice, arqIndex, cabecalhoIndex, &cont);

    LISTA *removidos = criaLista();
    inicializaLista(removidos, arqDados, cabecalho.topo);

    for(int i=0; i<n; i++){
        int id=-1, idade=-1, parametros=0;
        char nomeJogador[30] = "", nacionalidade[30] = "", nomeClube[30] = "";

        scanf("%d", &parametros);
        for(int j=0; j<parametros; j++){
            char busca[255];
            scanf("%s", busca);
            if (strcmp(busca, "id") == 0) {
                scanf("%d", &id);
            } else if (strcmp(busca, "idade") == 0) {
                scanf("%d", &idade);
            } else if (strcmp(busca, "nomeJogador") == 0) {
                scan_quote_string(nomeJogador);
            } else if (strcmp(busca, "nacionalidade") == 0) {
                scan_quote_string(nacionalidade);
            } else if (strcmp(busca, "nomeClube") == 0) {
                scan_quote_string(nomeClube);
            }
        }
        
        if(id != -1){
            for(int j=0; j<cont; j++){
                if(indice[j].id == id){
                    long int offset = indice[j].byteoffset;
                    fseek(arqDados, offset, SEEK_SET);
                    Registro reg;
                    fread(&reg.removido, sizeof(char), 1, arqDados);
                    fread(&reg.tamanhoRegistro, sizeof(int), 1, arqDados);
                    if(reg.removido == '0'){
                        lerRegistro(&reg, arqDados, 0);
                        int valido = 1;
                        if (idade != -1 && reg.idade != idade)
                            valido = 0;
                        if (strcmp(nomeJogador, "") != 0 && strcmp(reg.nomeJogador, nomeJogador) != 0)
                            valido = 0;
                        if (strcmp(nacionalidade, "") != 0 && strcmp(reg.nacionalidade, nacionalidade) != 0)
                            valido = 0;
                        if (strcmp(nomeClube, "") != 0 && strcmp(reg.nomeClube, nomeClube) != 0)
                            valido = 0;

                        if(valido){
                            insereOrdenado(removidos, offset, reg.tamanhoRegistro);

                            reg.removido = '1';
                            reg.Prox = getOffsetProx(removidos, offset);
                            fseek(arqDados, offset, SEEK_SET);
                            escreverRegistro(&reg, arqDados);

                            NO *atual = removidos->cabeca;
                            while (atual != NULL && atual->prox != NULL){
                                if (atual->prox->offset == offset) {
                                    long int posAnterior = atual->offset;
                                    Registro regAnterior;
                                    fseek(arqDados, posAnterior, SEEK_SET);
                                    lerRegistro(&regAnterior, arqDados, 1);
                                    regAnterior.Prox = offset;
                                    fseek(arqDados, posAnterior, SEEK_SET);
                                    escreverRegistro(&regAnterior, arqDados);
                                    freeRegistro(&regAnterior);
                                    break;
                                }
                                atual = atual->prox;
                            }
                            cabecalho.nroRegArq--;
                            cabecalho.nroRegRem++;

                            fseek(arqDados, offset+reg.tamanhoRegistro, SEEK_SET);
                        }
                        freeRegistro(&reg);
                    }else{
                        break;
                    }
                }
            }
        }else{
            
            fseek(arqDados, 25, SEEK_SET);
            Registro registro;
            long int offset;
            for(int k=0; k<cabecalho.nroRegArq+cabecalho.nroRegRem; k++){
                offset = ftell(arqDados);
                fread(&registro.removido, sizeof(char), 1, arqDados);
                fread(&registro.tamanhoRegistro, sizeof(int), 1, arqDados);
                if(registro.removido == '0'){
                    lerRegistro(&registro, arqDados, 0);
                    int valido=1;
                    if (id != -1 && registro.id != id)
                        valido = 0;
                    if (idade != -1 && registro.idade != idade)
                        valido = 0;
                    if (strcmp(nomeJogador, "") != 0 && strcmp(registro.nomeJogador, nomeJogador) != 0)
                        valido = 0;
                    if (strcmp(nacionalidade, "") != 0 && strcmp(registro.nacionalidade, nacionalidade) != 0)
                        valido = 0;
                    if (strcmp(nomeClube, "") != 0 && strcmp(registro.nomeClube, nomeClube) != 0)
                        valido = 0;
                    
                    if(valido){
                        insereOrdenado(removidos, offset, registro.tamanhoRegistro);

                        registro.removido = '1';
                        registro.Prox = getOffsetProx(removidos, offset);

                        fseek(arqDados, offset, SEEK_SET);
                        escreverRegistro(&registro, arqDados);

                        NO *atual = removidos->cabeca;
                        while(atual != NULL && atual->prox != NULL){
                            if(atual->prox->offset == offset){
                                long int posAnterior = atual->offset;
                                Registro regAnterior;
                                fseek(arqDados, posAnterior, SEEK_SET);
                                lerRegistro(&regAnterior, arqDados, 1);
                                regAnterior.Prox = offset;

                                fseek(arqDados, posAnterior, SEEK_SET);
                                escreverRegistro(&regAnterior, arqDados);
                                freeRegistro(&regAnterior);
                                break;
                            }
                            atual = atual->prox;
                        }

                        cabecalho.nroRegArq--;
                        cabecalho.nroRegRem++;

                        fseek(arqDados, offset+registro.tamanhoRegistro, SEEK_SET);
                    }
                    freeRegistro(&registro);
                }else{
                    fseek(arqDados, registro.tamanhoRegistro-5, SEEK_CUR);
                }
            }
        }
    }

    cabecalho.status = '1';
    cabecalho.topo = getTopo(removidos);
    fseek(arqDados, 0, SEEK_SET);
    escreverCabecalho(&cabecalho, arqDados);
    fclose(arqDados);
    
    createIndex(arq, "temp_index.bin");

    remove(index);
    rename("temp_index.bin", index);

    fclose(arqIndex);
    liberarLista(removidos);

    return 1;
}

int insertInto(char *arq, char *index, int n) {
    FILE *arqDados = fopen(arq, "r+b");
    if (!abreArquivo(arqDados))
        return 0;
    if (!trataStatus(arqDados)) {
        fclose(arqDados);
        return 0;
    }

    FILE *arqIndex = fopen(index, "w+b");
    if (!abreArquivo(arqIndex)) {
        fclose(arqDados);
        return 0;
    }
    createIndex(arq, index);

    FILE *tmpIndex = fopen("temp_index.bin", "wb");
    if (!abreArquivo(tmpIndex)) {
        fclose(arqDados);
        fclose(arqIndex);
        return 0;
    }

    Cabecalho cabecalho;
    fseek(arqDados, 0, SEEK_SET);
    lerCabecalho(&cabecalho, arqDados);
    cabecalho.status = '0';

    LISTA *removidos = criaLista();
    inicializaLista(removidos, arqDados, cabecalho.topo);

    for (int i = 0; i < n; i++) {
        int id = -1, idade = -1, tamNomeJog = 0, tamNacionalidade = 0, tamNomeClube = 0;
        char leID[10] = "", leIdade[10] = "", nomeJogador[30] = "", nacionalidade[30] = "", nomeClube[30] = "";

        scan_quote_string(leID);
        if (strcmp(leID, "") != 0) {
            id = atoi(leID);
        }
        scan_quote_string(leIdade);
        if (strcmp(leIdade, "") != 0) {
            idade = atoi(leIdade);
        }
        scan_quote_string(nomeJogador);
        if (strcmp(nomeJogador, "") != 0) {
            tamNomeJog = strlen(nomeJogador);
        }
        scan_quote_string(nacionalidade);
        if (strcmp(nacionalidade, "") != 0) {
            tamNacionalidade = strlen(nacionalidade);
        }
        scan_quote_string(nomeClube);
        if (strcmp(nomeClube, "") != 0) {
            tamNomeClube = strlen(nomeClube);
        }

        fseek(arqDados, 0, SEEK_SET);

        Registro registro;
        inicializaRegistro(&registro, id, idade, tamNomeJog, nomeJogador, tamNacionalidade, nacionalidade, tamNomeClube, nomeClube);
        int tamNecessario = 6 * sizeof(int) + sizeof(long int) + sizeof(char) * (tamNomeJog + tamNacionalidade + tamNomeClube + 1);

        if (cabecalho.topo == -1) {
            fseek(arqDados, cabecalho.proxByteOffset, SEEK_SET);
            registro.tamanhoRegistro = tamNecessario;
            escreverRegistro(&registro, arqDados);
            cabecalho.proxByteOffset += tamNecessario;
            cabecalho.nroRegArq++;
        } else {
            NO *melhor = bestFit(removidos, tamNecessario);

            if (melhor != NULL) {
                fseek(arqDados, melhor->offset, SEEK_SET);
                registro.tamanhoRegistro = melhor->tamReg;
                escreverRegistro(&registro, arqDados);

                if (melhor->tamReg > tamNecessario) {
                    int espacoRestante = melhor->tamReg - tamNecessario;
                    fseek(arqDados, melhor->offset + tamNecessario, SEEK_SET);
                    for (int j = 0; j < espacoRestante; j++) {
                        fwrite("$", sizeof(char), 1, arqDados);
                    }
                }

                // Atualiza o campo `prox` do registro anterior ao reaproveitado
                NO *anterior = removidos->cabeca;
                while (anterior != NULL && anterior->prox != melhor) {
                    anterior = anterior->prox;
                }
                if (anterior != NULL) {
                    anterior->prox = melhor->prox;

                    fseek(arqDados, anterior->offset, SEEK_SET);
                    Registro regAnterior;
                    lerRegistro(&regAnterior, arqDados, 1);
                    if(anterior->prox != NULL)
                        regAnterior.Prox = anterior->prox->offset;
                    else
                        regAnterior.Prox = -1;
                    fseek(arqDados, anterior->offset, SEEK_SET);
                    escreverRegistro(&regAnterior, arqDados);
                    freeRegistro(&regAnterior);
                }

                cabecalho.nroRegArq++;
                cabecalho.nroRegRem--;

                NO *removido = removeLista(removidos, melhor);
                if (removido != NULL) {
                    free(removido);
                }
            } else {
                fseek(arqDados, cabecalho.proxByteOffset, SEEK_SET);
                registro.tamanhoRegistro = tamNecessario;
                escreverRegistro(&registro, arqDados);
                cabecalho.proxByteOffset += tamNecessario;
                cabecalho.nroRegArq++;
            }
        }
        freeRegistro(&registro);
    }

    cabecalho.topo = getTopo(removidos);
    cabecalho.status = '1';
    fseek(arqDados, 0, SEEK_SET);
    escreverCabecalho(&cabecalho, arqDados);
    fclose(arqDados);

    createIndex(arq, "temp_index.bin");

    remove(index);
    rename("temp_index.bin", index);

    fclose(arqIndex);
    liberarLista(removidos);

    return 1;
}


int main(){
    //main que le a operacao a ser realizada e chama a funcao correspondente com os args necessarios
    char arg1[30], arg2[30];
    int op=0, n=0;

    scanf("%d", &op);
    scanf("%s", arg1);

    switch(op){
        case 1:
            scanf("%s", arg2);
            createTable(arg1, arg2);
            break;
        case 2:
            selectFrom(arg1);
            break;
        case 3:
            scanf("%d", &n);
            selectWhere(arg1, n);
            break;
        case 4:
            scanf("%s", arg2);
            if(createIndex(arg1, arg2) == 1)
                binarioNaTela(arg2);
            break;
        case 5:
            scanf("%s", arg2);
            scanf("%d", &n);
            if(deleteWhere(arg1, arg2, n) == 1){
                binarioNaTela(arg1);
                binarioNaTela(arg2);
            }
            break;
        case 6:
            scanf("%s", arg2);
            scanf("%d", &n);
            if(insertInto(arg1, arg2, n) == 1){
                binarioNaTela(arg1);
                binarioNaTela(arg2);
            }
            break;
        default:
            break;
    }

    return 0;
}
