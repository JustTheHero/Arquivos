#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int preencheCampoFixo(char *campo){
    if(strlen(campo) == 0){
        return -1;
    }
    else{
        return atoi(campo);
    }
}
void abrir(char arg1[]){ ////select from versao teste
    FILE *arq;
    arq = fopen(arg1, "rb");
    if (arq == NULL) {
        printf("Erro ao abrir o arquivo\n");
        exit(1);
    }

    fseek(arq, 17, SEEK_SET);
    int nroRegArq, nroRegRem;
    fread(&nroRegArq, sizeof(int), 1, arq);
    fread(&nroRegRem, sizeof(int), 1, arq);

    char removido, *nome, *naci, *clube;
    int tam, id, idade, tamnome, tamnaci, tamclube;
    long int prox;
    fseek(arq, 25, SEEK_SET);
    for (int i = 0; i < nroRegArq+nroRegRem; i++) {
                
             fread(&removido, sizeof(char), 1, arq);
    fread(&tam, sizeof(int), 1, arq);
    fread(&prox, sizeof(long int), 1, arq);
    fread(&id, sizeof(int), 1, arq);
    fread(&idade, sizeof(int), 1, arq);
    fread(&tamnome, sizeof(int), 1, arq);
    nome = (char *) malloc(tamnome * sizeof(char));
    fread(nome, sizeof(char), tamnome, arq);
    fread(&tamnaci, sizeof(int), 1, arq);
    naci = (char *) malloc(tamnaci * sizeof(char));
    fread(naci, sizeof(char), tamnaci, arq);
    fread(&tamclube, sizeof(int), 1, arq);
    clube = (char *) malloc(tamclube * sizeof(char));
    fread(clube, sizeof(char), tamclube, arq);


                printf("Nome do Jogador: %s\n", tamnome ? nome : "SEM DADO");
                printf("Nacionalidade: %s\n", tamnaci ? naci : "SEM DADO");
                printf("Nome do Clube: %s\n", tamclube ? clube : "SEM DADO");
                printf("\n");
    


    free(nome); free(naci); free(clube);
}
fclose(arq);
}

void ler(char arg1[]){ ////create versao teste
    FILE *arq;
    arq = fopen(arg1, "r");
    if (arq == NULL) {
        printf("Erro ao abrir o arquivo\n");
        exit(1);
    }

    char buffer[45];
    fread(buffer, sizeof(char), 45, arq);
    printf("%s\n", buffer);

    int id, idade, tamnome, tamnaci, tamclube;
char *nome, *naci, *clube, teste[30], linha[100], c;
int k=0;
while(!feof(arq)){
    int i=0, j=0;
    while((c = fgetc(arq)) != '\n'){
        linha[i] = c;
        i++;
    }
    linha[i] = '\0';
    
    i=0;

    // Extracting id
    while(linha[i] != ','){
        teste[j] = linha[i];
        j++;
        i++;
    }
    teste[j] = '\0';
    id = preencheCampoFixo(teste);
    i++; j=0;

    // Extracting idade
    while(linha[i] != ','){
        teste[j] = linha[i];
        j++;
        i++;
    }
    teste[j] = '\0';
    idade = preencheCampoFixo(teste);
    i++; j=0;

    // Extracting nome
    while(linha[i] != ','){
        teste[j] = linha[i];
        j++;
        i++;
    }
    teste[j] = '\0';
    tamnome = strlen(teste);
    nome = (char *)malloc((tamnome + 1) * sizeof(char)); // Allocate memory for nome
    strcpy(nome, teste); // Copy the string to nome
    i++; j=0;

    // Extracting naci
    while(linha[i] != ','){
        teste[j] = linha[i];
        j++;
        i++;
    }
    teste[j] = '\0';
    tamnaci = strlen(teste);
    naci = (char *)malloc((tamnaci + 1) * sizeof(char)); // Allocate memory for naci
    strcpy(naci, teste); // Copy the string to naci
    i++; j=0;

    // Extracting clube
    while(linha[i] != '\0'){
        teste[j] = linha[i];
        j++;
        i++;
    }
    teste[j] = '\0';
    tamclube = strlen(teste);
    clube = (char *)malloc((tamclube + 1) * sizeof(char)); // Allocate memory for clube
    strcpy(clube, teste); // Copy the string to clube

    // Output the extracted data
    printf("%d %d %d %d %d %d %s %s %s\n", id, idade, tamnome, tamnaci, tamclube, (int)strlen(nome), nome, naci, clube);

    // Free memory and reset pointers
    free(nome); free(naci); free(clube);
    nome = NULL; naci = NULL; clube = NULL;
    k++;
}
fclose(arq);

}

int main(){

    char arg1[30], arg2[30];
    int op=0, n=0;
    scanf("%d", &op);
    
    // Verifica a operação e lê os argumentos correspondentes
        scanf("%s", arg1);
    // Executa as operações conforme a entrada
    if (op == 1) {
        abrir(arg1);
    } else
        ler(arg1);

    return 0;
}