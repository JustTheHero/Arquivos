#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "funcoes_fornecidas.h"

//Trabalho 1 - Organização de Arquivos
//Alunos: Gabriel Hyppolito - 14571810, Juan Marques Jordão - 14758742

typedef struct{
    char status;
    long int topo, proxByteOffset;
    int nroRegArq, nroRegRem;
}Cabecalho;
typedef struct{
    int id, idade, tamanhoRegistro, tamNomeJog, tamNacionalidade, tamNomeClube;
    long int prox;
    char removido, *nomeJogador, *nacionalidade, *nomeClube;
}Registro;

bool abreBinRead(char *nomeArquivo, FILE **arquivo){
    *arquivo = fopen(nomeArquivo, "rb");
    if(*arquivo == NULL){
        printf("Falha no processamento do arquivo.\n");
        return false;
    }
    return true;
}

//FUNCOES
char *lerString(FILE *arquivo, int tamanho){
    char *string = (char *)malloc(tamanho);
    fread(string, tamanho, 1, arquivo);
    return string;
}
void exibirString(char *string, int  tamanho){
    if (tamanho == -1) {
        printf("Falha no processamento do arquivo.\n");
    } else {
        printf("%s\n", string);
    }
}

void inicializarCabecalho(Cabecalho *cabecalho){
    cabecalho->status = '0';
    cabecalho->topo = -1;
    cabecalho->proxByteOffset = 0;
    cabecalho->nroRegArq = 0;
    cabecalho->nroRegRem = 0;
}

void escreverCabecalho(Cabecalho *cabecalho, FILE *arquivo){
    fwrite(&cabecalho->status, sizeof(char), 1, arquivo);
    fwrite(&cabecalho->topo, sizeof(long int), 1, arquivo);
    fwrite(&cabecalho->proxByteOffset, sizeof(long int), 1, arquivo);
    fwrite(&cabecalho->nroRegArq, sizeof(int), 1, arquivo);
    fwrite(&cabecalho->nroRegRem, sizeof(int), 1, arquivo);
}

void lerRegistro(Registro *registro, FILE *arquivo){
    fread(&registro->tamanhoRegistro, sizeof(int), 1, arquivo);
    fread(&registro->prox, sizeof(long int), 1, arquivo);
    fread(&registro->id, sizeof(int), 1, arquivo);
    fread(&registro->idade, sizeof(int), 1, arquivo);
    fread(&registro->tamNomeJog, sizeof(int), 1, arquivo);
    registro->nomeJogador = lerString(arquivo, registro->tamNomeJog);
    fread(&registro->tamNacionalidade, sizeof(int), 1, arquivo);
    registro->nacionalidade = lerString(arquivo, registro->tamNacionalidade);
    fread(&registro->tamNomeClube, sizeof(int), 1, arquivo);
    registro->nomeClube = lerString(arquivo, registro->tamNomeClube);
}

void escreverRegistro(Registro *registro, FILE *arquivo){
    fwrite(&registro->removido, sizeof(char), 1, arquivo);
    fwrite(&registro->tamanhoRegistro, sizeof(int), 1, arquivo);
    fwrite(&registro->prox, sizeof(long int), 1, arquivo);
    fwrite(&registro->id, sizeof(int), 1, arquivo);
    fwrite(&registro->idade, sizeof(int), 1, arquivo);
    fwrite(&registro->tamNomeJog, sizeof(int), 1, arquivo);
    fwrite(registro->nomeJogador, registro->tamNomeJog, 1, arquivo);
    fwrite(&registro->tamNacionalidade, sizeof(int), 1, arquivo);
    fwrite(registro->nacionalidade, registro->tamNacionalidade, 1, arquivo);
    fwrite(&registro->tamNomeClube, sizeof(int), 1, arquivo);
    fwrite(registro->nomeClube, registro->tamNomeClube, 1, arquivo);
}

char *leCampo(char *linha, int *i){
    int j=0;
    char *tempStr = (char *)malloc(30*sizeof(char));
    while(linha[*i] != ','){
        tempStr[j] = linha[*i];
        j++;
        (*i)++;
    }
    (*i)++;
    tempStr[j] = '\0';
    return tempStr;
}

char *leUltimoCampo(char *linha, int *i){
    int j=0;
    char *tempStr = (char *)malloc(30*sizeof(char));
    while(linha[*i] != '\0'){
        tempStr[j] = linha[*i];
        j++;
        (*i)++;
    }
    tempStr[j] = '\0';
    return tempStr;
}

int preencheCampoFixo(char *chave){
    if(strlen(chave) == 0){
        return -1;
    }else{
        return atoi(chave);
    }
}

int tamanhoString(char *str){
    if(str == NULL){
        return 0;
    }else{
        return strlen(str);
    }

}

void createTable(char *entrada, char *saida){

    printf("a");
    FILE *arquivoEntrada = fopen(entrada, "r");
    if(arquivoEntrada == NULL){
        printf("Falha no processamento do arquivo.\n");
        return;
    }
    
    FILE *arquivoSaida = fopen(saida, "wb");
    if(arquivoSaida == NULL){
        printf("Falha no processamento do arquivo.\n");
        return;
    }
        
        printf("b");

        Cabecalho cabecalho;
        inicializarCabecalho(&cabecalho);
        
        char buffer[45];
        fread(buffer, 45, 1, arquivoEntrada);
        
        Registro registro;

        while(!feof(arquivoEntrada)){
            
            char c, linha[100], *nome;
            int i=0, j=0;
            while((c = fgetc(arquivoEntrada)) != '\n'){
                linha[i] = c;
                i++;
            }
            linha[i] = '\0';
            i=0;

            //inicializar registro
            nome = (char *)malloc(30*sizeof(char));
            
            registro.id = preencheCampoFixo(leCampo(linha, &i));
            registro.idade = preencheCampoFixo(leCampo(linha, &i));
            
            strcpy(nome, leCampo(linha, &i));
            registro.tamNomeJog = strlen(nome);
            if(registro.tamNomeJog != 0){
                registro.nomeJogador = (char *)malloc(sizeof(char)*registro.tamNomeJog);
                memcpy(registro.nomeJogador, nome, registro.tamNomeJog);
            }else{
                registro.nomeJogador = NULL;
            }
            free(nome); nome = NULL;

            strcpy(nome, leCampo(linha, &i));
            registro.tamNacionalidade = strlen(nome);
            if(registro.tamNacionalidade != 0){
                registro.nacionalidade = (char *)malloc(registro.tamNacionalidade*sizeof(char));
                memcpy(registro.nacionalidade, nome, registro.tamNacionalidade);
            }else{
                registro.nacionalidade = NULL;
            }
            free(nome); nome = NULL;

            strcpy(nome, leCampo(linha, &i));
            registro.tamNomeClube = strlen(nome);
            if(registro.tamNomeClube != 0){
                registro.nomeClube = (char *)malloc(registro.tamNomeClube*sizeof(char));
                memcpy(registro.nomeClube, nome, registro.tamNomeClube);
            }else{
                registro.nomeClube = NULL;
            }
            free(nome); nome = NULL;
            
            registro.removido = '0';
            registro.prox = -1;
            registro.tamanhoRegistro = sizeof(int)*6 + sizeof(long int) + sizeof(char)*(registro.tamNomeJog + 
                                        registro.tamNacionalidade + registro.tamNomeClube + 1);

            escreverRegistro(&registro, arquivoSaida);
            cabecalho.nroRegArq++;
            free(registro.nomeJogador); registro.nomeJogador = NULL;
            free(registro.nacionalidade); registro.nacionalidade = NULL;
            free(registro.nomeClube); registro.nomeClube = NULL;
        }

        //atualizacao do status do cabecalho
        //atualiza proxbyteoffset e escreve cabecalho
        cabecalho.status = '1';
        cabecalho.proxByteOffset = ftell(arquivoSaida);
        fseek(arquivoSaida, 0, SEEK_SET);
        escreverCabecalho(&cabecalho, arquivoSaida);


        fclose(arquivoEntrada);
        fclose(arquivoSaida);

        binarioNaTela(saida);
}

void select_from(char *arqbin){
        FILE *arquivo;
        if(!abreBinRead(arqbin, &arquivo)){
            return;
        }else{
            //dar tab no pc
        fseek(arquivo, 16, SEEK_SET);
        int nroRegArq, nroRegRem;
        fread(&nroRegArq, sizeof(int), 1, arquivo);
        fread(&nroRegRem, sizeof(int), 1, arquivo);
        
        if(nroRegArq == 0){
            printf("Registro inexistente.\n");
            printf("\n");
            fclose(arquivo);
            return;
        }

        Registro registro;//fazer casos de erro, int -1 se for int, $ se for string, etc
        for (int i = 0; i < nroRegArq+nroRegRem; i++) {
            fread(&registro.removido, sizeof(char), 1, arquivo);
            if(registro.removido == '0'){
                lerRegistro(&registro, arquivo);
                
                printf("Nome do Jogador: %s\n", registro.tamNomeJog ? registro.nomeJogador : "SEM DADO");
                printf("Nacionalidade: %s\n", registro.tamNacionalidade ? registro.nacionalidade : "SEM DADO");
                printf("Nome do Clube: %s\n", registro.tamNomeClube ? registro.nomeClube : "SEM DADO");
                printf("\n");
                
                free(registro.nomeJogador);
                free(registro.nacionalidade);
                free(registro.nomeClube);
            }
            else{
                fseek(arquivo, -1, SEEK_CUR);
                fseek(arquivo, registro.tamanhoRegistro, SEEK_CUR);
            }
    }
    fclose(arquivo);
    }
}


int verificarRegistro(Registro *registro, int id, int idade, char *nomeJogador, char *nacionalidade, char *nomeClube) {
    if ((id == -1 || registro->id == id) &&
        (idade == -1 || registro->idade == idade) &&
        (strcmp(nomeJogador, "") == 0 || strcmp(registro->nomeJogador, nomeJogador) == 0) &&
        (strcmp(nacionalidade, "") == 0 || strcmp(registro->nacionalidade, nacionalidade) == 0) &&
        (strcmp(nomeClube, "") == 0 || strcmp(registro->nomeClube, nomeClube) == 0)) {
        return 1;  
    }
    return 0;  
}
void select_where(char *arqbin, int n){//codar interação com verificacao de registros

        FILE *arquivo;
        abreBinRead(arqbin, &arquivo);
        
        fseek(arquivo, 16, SEEK_SET);
        int nroRegArq, nroRegRem;
        fread(&nroRegArq, sizeof(int), 1, arquivo);
        fread(&nroRegRem, sizeof(int), 1, arquivo);
        if(nroRegArq == 0){
            printf("Registro inexistente.\n");
            fclose(arquivo);
            return;
        }   
        Registro registro;
        for (int i = 0; i < n; i++) {
            int id = -1, idade = -1;
            char nomeJogador[50] = "", nacionalidade[50] = "", nomeClube[50] = "";
            char busca[255];
            fgets(busca, 255, stdin);
            char *token = strtok(busca, " \n");
            while (token != NULL) {
                if (strcmp(token, "id") == 0) {
                    token = strtok(NULL, " \n");
                    id = atoi(token);
                } else if (strcmp(token, "idade") == 0) {
                    token = strtok(NULL, " \n");
                    idade = atoi(token);
                } else if (strcmp(token, "nomeJogador") == 0) {
                    token = strtok(NULL, " \n");
                    strcpy(nomeJogador, token);
                } else if (strcmp(token, "nacionalidade") == 0) {
                    token = strtok(NULL, " \n");
                    strcpy(nacionalidade, token);
                } else if (strcmp(token, "nomeClube") == 0) {
                    token = strtok(NULL, " \n");
                    strcpy(nomeClube, token);
                }
                token = strtok(NULL, " \n");
        }
        while (fread(&registro, sizeof(registro), 1, arquivo)) {
            if (verificarRegistro(&registro, id, idade, nomeJogador, nacionalidade, nomeClube)) {
                printf("%d %d %s %s %s\n", registro.id, registro.idade, registro.nomeJogador, registro.nacionalidade, registro.nomeClube);
            }
        }
    }
    fclose(arquivo);
}

int main(){
    
    //MENU DE ESCOLHA DE FUNCAO BASEADO EM TD MESMA LINHA
    //se entrada for parametro de execucao trocar p argv
    char arg1[30], arg2[30];
    int op=0, n=0;
    scanf("%d", &op);
    
    printf("1");
    // Verifica a operação e lê os argumentos correspondentes
    if (op == 1 || op == 3) {
        scanf("%s %s", arg1, arg2);
    } else if (op == 2) {
        scanf("%s", arg1);
    }

    printf("2");
    // Executa as operações conforme a entrada
    if (op == 1) {
        createTable(arg1, arg2);
    } else if (op == 3) {
        n = atoi(arg2);
        select_where(arg1, n);
    } else if (op == 2) {
        select_from(arg1);
    }
        
    return 0;
}
