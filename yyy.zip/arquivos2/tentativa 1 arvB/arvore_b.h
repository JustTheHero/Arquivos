#ifndef ARVB_H
#define ARVB_H

#include "auxiliares.h"

#define ORDEM 4
#define MIN 2
#define TAM_CAB 60

//structs para o arquivo de indices arvore B
typedef struct {
    char status;
    int noRaiz;
    int proxRRN;
    int nroChaves;
} CabecalhoIndexB;

//struct para registros arvore B
typedef struct noB {
    int chave[ORDEM - 1]; // Ajustado para corresponder à ordem
    long int ptrDados[ORDEM - 1];
    int filhos[ORDEM];
    int nroChaves, alturaNo;
} RegBTree;

void escreverNo(FILE *arquivo, RegBTree *no, int rrn);
void lerNo(FILE *arquivo, RegBTree *no, int rrn);
void inicializaCabecalhoB(CabecalhoIndexB *cabecalho, FILE *arquivo);
void attCabecalhoB(CabecalhoIndexB *cabecalho, FILE *arquivo);
RegBTree *createNode(int chave, long int ptrDado, int childRRN);
void insertNode(int chave, long int ptrDado, int pos, RegBTree *node, int childRRN);
void splitNode(int chave, long int ptrDado, int *pchave, long int *pptrDado, int pos, RegBTree *node, int childRRN, RegBTree **newNode);
int setValue(int chave, long int ptrDado, int *pchave, long int *pptrDado, RegBTree *node, int *childRRN, FILE *arquivoIndice, CabecalhoIndexB *cabecalhoIndex);
void insert(int chave, long int ptrDado, FILE *arquivoIndice, CabecalhoIndexB *cabecalhoIndex);
void search(int chave, int *pos, int rrn, FILE *arquivoIndice);
void traversal(int rrn, FILE *arquivoIndice);

#endif
