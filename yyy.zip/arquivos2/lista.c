#include "lista.h"

//funcao que cria uma lista
LISTA *criaLista(){
    LISTA *l = (LISTA*)malloc(sizeof(LISTA));
    if(l != NULL){
        l->cabeca = NULL;
    }
    return l;
}

//funcao que inicializa a lista com os registros inicialmente marcados como removidos no arquivo de dados
void inicializaLista(LISTA *l, FILE *arqdados, long int offset){
    fseek(arqdados, 0, SEEK_SET);

    //enquanto houver registros marcados como removidos
    while(offset != -1){
        fseek(arqdados, offset, SEEK_SET);

        char removido;
        int tamanhoRegistro;
        long int prox;

        fread(&removido, sizeof(char), 1, arqdados);
        fread(&tamanhoRegistro, sizeof(int), 1, arqdados);
        fread(&prox, sizeof(long int), 1, arqdados);

        //insere o registro com o offset e o tamanho na lista e atualiza o offset para o proximo
        insereOrdenado(l, offset, tamanhoRegistro);
        offset = prox;
    }

}

//insere um novo registro na lista, usando o tamanho do registro como criterio de ordenacao
void insereOrdenado(LISTA *l, long int offset, int tamReg){
    
    //aloca um novo no para os dados do registro
    NO *novo = (NO*)malloc(sizeof(NO));
    if(novo != NULL){
        novo->offset = offset;
        novo->tamReg = tamReg;
        novo->prox = NULL;

        //se a lista estiver vazia ou o tamanho do registro for menor que o tamanho do registro do primeiro no
        if(l->cabeca == NULL || l->cabeca->tamReg > tamReg){
            novo->prox = l->cabeca;
            l->cabeca = novo;
        }else{

            //se nao, percorre a lista ate encontrar um no em que o tamanho do proximo no seja maior que o tamanho do registro
            NO *atual = l->cabeca;
            while(atual->prox != NULL && atual->prox->tamReg <= tamReg){
                atual = atual->prox;
            }

            //insere o novo no antes do no com tamanho de registro maior, atualizando os campos
            novo->prox = atual->prox;
            atual->prox = novo;
        }
    }
}


//remove um no fornecido da lista, atualizando os ponteiros
NO* removeLista(LISTA *l, NO *no) {
    if (l->cabeca == NULL) return NULL;

    if (l->cabeca == no) {
        l->cabeca = no->prox;
    } else {
        NO *atual = l->cabeca;
        while (atual->prox != no && atual->prox != NULL) {
            atual = atual->prox;
        }
        if (atual->prox == no)
            atual->prox = no->prox;
    }
    return no;
}

//recebe um tamanho de registro e busca, na lista, o no com tamanho mais proximo, retornando ele
NO *bestFit(LISTA *l, int tamReg){
    NO* atual = l->cabeca;
    NO* melhor = NULL;

    //loop que percorre a lista, comparando o tamanho do no atual com o tamanho desejado
    while(atual != NULL){
        if(atual->tamReg >= tamReg){
            if(atual->tamReg == tamReg) return atual;

            //se o tamanho do no atual for maior que o tamanho desejado e for o melhor ate agora, atualiza o melhor
            if(melhor == NULL || atual->tamReg < melhor->tamReg){
                melhor = atual;
            }
        }
        atual = atual->prox;
    }

    return melhor;
}

//libera a memoria alocada para a lista
void liberarLista(LISTA *l){
    NO *atual = l->cabeca;
    while(atual != NULL){
        NO *aux = atual->prox;
        free(atual);
        atual = aux;
    }
    free(l);
}

//retorna o offset do proximo no da lista, a partir de um offset fornecido
long int getOffsetProx(LISTA *l, long int offset){
    NO *atual = l->cabeca;
    while(atual != NULL && atual->offset != offset){
        atual = atual->prox;
    }
    if(atual != NULL && atual->prox != NULL){
        return atual->prox->offset;
    }
    return -1;
}

//retorna o offset do no que esta na cabeca da lista
long int getTopo(LISTA *l){
    if(l->cabeca != NULL){
        return l->cabeca->offset;
    }
    return -1;
}

//funcao de impressao, usada para debug
void imprimeLista(LISTA *l){
    NO *atual = l->cabeca;
    while(atual != NULL){
        printf("Offset: %ld | ", atual->offset);
        printf("Tamanho do registro: %d\n", atual->tamReg);
        atual = atual->prox;
    }
}