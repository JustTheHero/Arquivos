#ifndef FUNCIONALIDADES_H
#define FUNCIONALIDADES_H
#include "auxiliares.h"

void createTable(char *entrada, char *saida);
void selectFrom(char* arq);
void selectWhere(char* arqBin, int n);
int createIndex(char *nomedados, char *nomeindex);
int deleteWhere(char *arq, char *index, int n);
int insertInto(char *arq, char *index, int n);
int createIndexB(char *arq, char *index);
void selectIdB(char *arq, char *index, int n);
void selectWhereB(char *arq, char *index, int n);
int insertIntoB(char *arq, char *index, int n);

#endif