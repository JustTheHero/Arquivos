#include "auxiliares.h"

//funcao para testar se o arquivo foi aberto corretamente
bool abreArquivo(FILE *arquivo){
    if(arquivo == NULL){
        printf("Falha no processamento do arquivo.\n");
        return false;
    }
    return true;
}

//funcao chamada para definir o estado inicial do cabeçalho
void inicializarCabecalho(Cabecalho *cabecalho){
    cabecalho->status = '0';
    cabecalho->topo = -1;
    cabecalho->proxByteOffset = 0;
    cabecalho->nroRegArq = 0;
    cabecalho->nroRegRem = 0;
}

//funcao chamada para escrita do cabecalho no arquivo de saida
void escreverCabecalho(Cabecalho *cabecalho, FILE *arquivo){
    fwrite(&cabecalho->status, sizeof(char), 1, arquivo);
    fwrite(&cabecalho->topo, sizeof(long int), 1, arquivo);
    fwrite(&cabecalho->proxByteOffset, sizeof(long int), 1, arquivo);
    fwrite(&cabecalho->nroRegArq, sizeof(int), 1, arquivo);
    fwrite(&cabecalho->nroRegRem, sizeof(int), 1, arquivo);
}

//funcao usada para leitura do cabecalho de um arquivo binario recebido e salva-lo na memoria principal para uso
void lerCabecalho(Cabecalho *cabecalho, FILE *arquivo){
    fread(&cabecalho->status, sizeof(char), 1, arquivo);
    fread(&cabecalho->topo, sizeof(long int), 1, arquivo);
    fread(&cabecalho->proxByteOffset, sizeof(long int), 1, arquivo);
    fread(&cabecalho->nroRegArq, sizeof(int), 1, arquivo);
    fread(&cabecalho->nroRegRem, sizeof(int), 1, arquivo);
}

//funcao usada pra ler campos de um arquivo binario recebido e salva-los na mem. principal para uso
void lerRegistro(Registro *registro, FILE *arquivo, int filtro){
            
    //filtro -> flag para indicar se eh necessaria leitura campos removido e tamanhoRegistro ou nao
    if(filtro == 1){
        fread(&registro->removido, sizeof(char), 1, arquivo);
        fread(&registro->tamanhoRegistro, sizeof(int), 1, arquivo);
        fread(&registro->Prox, sizeof(long int), 1, arquivo);
        fread(&registro->id, sizeof(int), 1, arquivo);
        fread(&registro->idade, sizeof(int), 1, arquivo);
        fread(&registro->tamNomeJog, sizeof(int), 1, arquivo);
        registro->nomeJogador = (char *)malloc((registro->tamNomeJog+1) * sizeof(char));
        fread(registro->nomeJogador, sizeof(char), registro->tamNomeJog, arquivo);
        fread(&registro->tamNacionalidade, sizeof(int), 1, arquivo);
        registro->nacionalidade = (char *)malloc((registro->tamNacionalidade+1) * sizeof(char));
        fread(registro->nacionalidade, sizeof(char), registro->tamNacionalidade, arquivo);
        fread(&registro->tamNomeClube, sizeof(int), 1, arquivo);
        registro->nomeClube = (char *)malloc((registro->tamNomeClube+1) * sizeof(char));
        fread(registro->nomeClube, sizeof(char), registro->tamNomeClube, arquivo);
    }else{
        fread(&registro->Prox, sizeof(long int), 1, arquivo);
        fread(&registro->id, sizeof(int), 1, arquivo);
        fread(&registro->idade, sizeof(int), 1, arquivo);
        fread(&registro->tamNomeJog, sizeof(int), 1, arquivo);
        registro->nomeJogador = (char *)malloc((registro->tamNomeJog+1) * sizeof(char));
        fread(registro->nomeJogador, sizeof(char), registro->tamNomeJog, arquivo);
        registro->nomeJogador[registro->tamNomeJog] = '\0';
        fread(&registro->tamNacionalidade, sizeof(int), 1, arquivo);
        registro->nacionalidade = (char *)malloc((registro->tamNacionalidade+1) * sizeof(char));
        fread(registro->nacionalidade, sizeof(char), registro->tamNacionalidade, arquivo);
        registro->nacionalidade[registro->tamNacionalidade] = '\0';
        fread(&registro->tamNomeClube, sizeof(int), 1, arquivo);
        registro->nomeClube = (char *)malloc((registro->tamNomeClube+1) * sizeof(char));
        fread(registro->nomeClube, sizeof(char), registro->tamNomeClube, arquivo);
        registro->nomeClube[registro->tamNomeClube] = '\0';
    }
}

//funcao usada para escrever um registro salvo na memoria principal no arquivo de saida, campo a campo
void escreverRegistro(Registro *registro, FILE *arquivo){
    fwrite(&registro->removido, sizeof(char), 1, arquivo);
    fwrite(&registro->tamanhoRegistro, sizeof(int), 1, arquivo);
    fwrite(&registro->Prox, sizeof(long int), 1, arquivo);
    fwrite(&registro->id, sizeof(int), 1, arquivo);
    fwrite(&registro->idade, sizeof(int), 1, arquivo);
    fwrite(&registro->tamNomeJog, sizeof(int), 1, arquivo);
    if(registro->tamNomeJog != 0)
        fwrite(registro->nomeJogador, registro->tamNomeJog, 1, arquivo);
    fwrite(&registro->tamNacionalidade, sizeof(int), 1, arquivo);
    if(registro->tamNacionalidade != 0)
        fwrite(registro->nacionalidade, registro->tamNacionalidade, 1, arquivo);
    fwrite(&registro->tamNomeClube, sizeof(int), 1, arquivo);
    if(registro->tamNomeClube != 0)
        fwrite(registro->nomeClube, registro->tamNomeClube, 1, arquivo);
}

//inicializa registro a ser adicionado com os campos lidos
void inicializaRegistro(Registro *registro, int id, int idade, int tamNomeJog, char *nomeJog, int tamNacionalidade, char *nacionalidade, int tamNomeClube, char *nomeClube){
    registro->removido = '0';
    registro->Prox = -1;
    registro->id = id;
    registro->idade = idade;
    registro->tamNomeJog = tamNomeJog;
    if(tamNomeJog == 0)
        registro->nomeJogador = NULL;
    else{
        registro->nomeJogador = (char *)malloc((tamNomeJog+1) * sizeof(char));
        strcpy(registro->nomeJogador, nomeJog);
    }
    registro->tamNacionalidade = tamNacionalidade;
    if(tamNacionalidade == 0)
        registro->nacionalidade = NULL;
    else{
        registro->nacionalidade = (char *)malloc((tamNacionalidade+1) * sizeof(char));
        strcpy(registro->nacionalidade, nacionalidade);
    }
    registro->tamNomeClube = tamNomeClube;
    if(tamNomeClube == 0)
        registro->nomeClube = NULL;
    else{
        registro->nomeClube = (char *)malloc((tamNomeClube+1) * sizeof(char));
        strcpy(registro->nomeClube, nomeClube);
    }

}

//funcao para preencher os campos id e idade do registro a partir da string obtida pela 
//logica de leitura dos dados do arquivo de entrada
int preencheCampoFixo(char *campo){
    if(strlen(campo) == 0)
        return -1;
    else
        return atoi(campo);
}

//funcao que le o status do arquivo e retorna se o arquivo esta consistente ou nao
bool trataStatus(FILE *arquivo){
    char status;
    fread(&status, sizeof(char), 1, arquivo);
    if(status == '0'){
        printf("Falha no processamento do arquivo.\n");
        return false;
    }
    return true;
}

//funcao que libera a memoria alocada para os campos de tamanho variavel do registro
void freeRegistro(Registro *registro){
     registro->nomeClube = NULL;
     registro->nacionalidade = NULL;
     registro->nomeJogador = NULL;
     free(registro->nomeClube);
     free(registro->nacionalidade);
     free(registro->nomeJogador);
}

//insere um registro no vetor de registros de indice, ordenando pelo id
void inserirIndice(RegistroIndex *indice, int *cont, RegistroIndex aux){
    int i = *cont - 1;
    while (i>=0 && indice[i].id > aux.id){
        indice[i+1] = indice[i];
        i--;
    }
    indice[i + 1] = aux;
    (*cont)++;
}

//escreve os registros de indice no arquivo de indice, com campos id e byteoffset
void escreveIndex(FILE *arqIndex, RegistroIndex *indice, int cont){
    for(int i=0; i<cont; i++){
        fwrite(&indice[i].id, sizeof(int), 1, arqIndex);
        fwrite(&indice[i].byteoffset, sizeof(long int), 1, arqIndex);
    }
}

void leIndice(RegistroIndex *indice, FILE *arqindex, CabecalhoIndex cabecalho, int *cont){
    fseek(arqindex, 0, SEEK_SET);
    fread(&cabecalho.status, sizeof(char), 1, arqindex);
    while(fread(&indice[*cont].id, sizeof(int), 1, arqindex) == 1){
        fread(&indice[*cont].byteoffset, sizeof(long int), 1, arqindex);
        (*cont)++;
    }
}

void lerCabecalhoB(CabecalhoIndexB *cabecalho, FILE *arquivo){
    fread(&cabecalho->status, sizeof(char), 1, arquivo);
    fread(&cabecalho->noRaiz, sizeof(int), 1, arquivo);
    fread(&cabecalho->proxRRN, sizeof(int), 1, arquivo);
    fread(&cabecalho->nroChaves, sizeof(int), 1, arquivo);
}