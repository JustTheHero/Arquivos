#ifndef ARVB_H
#define ARVB_H

#include "auxiliares.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#define ORDER 4
#define MAX_KEYS (ORDER - 1)
#define MIN_KEYS (ceil((ORDER / 2.0)) - 1)
#define NIL -1

typedef struct {
    char status;
    int noRaiz;
    int proxRRN;
    int nroChaves;
} CabecalhoIndexB;

typedef struct {
    int chave[MAX_KEYS];
    int PR[MAX_KEYS];
    int P[ORDER];
    int alturaNo;
    int numChaves;
    int RRN;
} PaginaB;


void inicializaCabecalhoB(CabecalhoIndexB *cabecalho, FILE *arquivo);
void attCabecalhoB(CabecalhoIndexB *cabecalho, FILE *arquivo);
int buscaPosicao(int chave, int *chaves, int numChaves);
void lePagina(FILE *arquivo, PaginaB *pagina, int RRN);
void escrevePagina(FILE *arquivo, PaginaB *pagina, int RRN);
int insert(FILE *arquivo, int CURRENT_RRN, int KEY, int *PROMO_KEY, int *PROMO_R_CHILD, CabecalhoIndexB *cabB);
void split(int I_KEY, int I_RRN, PaginaB *pagina, int *PROMO_KEY, int *PROMO_R_CHILD, PaginaB *newPage, int proxRRN);

#endif
