#include <stdio.h>
#include <stdlib.h>
#include "arvore_b.h"

void escreverNo(FILE *arquivo, RegBTree *no, int rrn) {
    fseek(arquivo, TAM_CAB + rrn * sizeof(RegBTree), SEEK_SET);
    
    fwrite(&no->alturaNo, sizeof(int), 1, arquivo);
    fwrite(&no->nroChaves, sizeof(int), 1, arquivo);
    for (int i = 0; i < ORDEM - 1; i++) {
        fwrite(&no->chave[i], sizeof(int), 1, arquivo);
        fwrite(&no->ptrDados[i], sizeof(long int), 1, arquivo);
    }
    for (int i = 0; i < ORDEM; i++) {
        fwrite(&no->filhos[i], sizeof(int), 1, arquivo);
    }
}

void lerNo(FILE *arquivo, RegBTree *no, int rrn) {
    fseek(arquivo, TAM_CAB + rrn * sizeof(RegBTree), SEEK_SET);
    
    fread(&no->alturaNo, sizeof(int), 1, arquivo);
    fread(&no->nroChaves, sizeof(int), 1, arquivo);
    for (int i = 0; i < ORDEM - 1; i++) {
        fread(&no->chave[i], sizeof(int), 1, arquivo);
        fread(&no->ptrDados[i], sizeof(long int), 1, arquivo);
    }
    for (int i = 0; i < ORDEM; i++) {
        fread(&no->filhos[i], sizeof(int), 1, arquivo);
    }
}

void inicializaCabecalhoB(CabecalhoIndexB* c, FILE* arq) {
    c->status = '0';
    c->noRaiz = -1;
    c->proxRRN = 0;
    c->nroChaves = 0;

    fwrite(&c->status, sizeof(char), 1, arq);
    fwrite(&c->noRaiz, sizeof(int), 1, arq);
    fwrite(&c->proxRRN, sizeof(int), 1, arq);
    fwrite(&c->nroChaves, sizeof(int), 1, arq);

    int restoCab = TAM_CAB - (3 * sizeof(int) + sizeof(char));
    char lixo = '$';
    for (int i = 0; i < restoCab; i++) {
        fwrite(&lixo, sizeof(char), 1, arq);
    }
}

void attCabecalhoB(CabecalhoIndexB* c, FILE* arq) {
    fseek(arq, 0, SEEK_SET);
    fwrite(&c->status, sizeof(char), 1, arq);
    fwrite(&c->noRaiz, sizeof(int), 1, arq);
    fwrite(&c->proxRRN, sizeof(int), 1, arq);
    fwrite(&c->nroChaves, sizeof(int), 1, arq);
}

RegBTree *createNode(int chave, long int ptrDado, int childRRN) {
    RegBTree *newNode = (RegBTree *)malloc(sizeof(RegBTree));
    newNode->chave[0] = chave;
    newNode->ptrDados[0] = ptrDado;
    for (int i = 0; i < ORDEM; i++) {
        newNode->filhos[i] = -1;
    }
    newNode->filhos[1] = childRRN;
    newNode->nroChaves = 1;
    newNode->alturaNo = 0; // Nó folha
    return newNode;
}

void insertNode(int chave, long int ptrDado, int pos, RegBTree *node, int childRRN) {
    int j = node->nroChaves;
    while (j > pos) {
        node->chave[j] = node->chave[j - 1];
        node->ptrDados[j] = node->ptrDados[j - 1];
        node->filhos[j + 1] = node->filhos[j];
        j--;
    }
    node->chave[j] = chave;
    node->ptrDados[j] = ptrDado;
    node->filhos[j + 1] = childRRN;
    node->nroChaves++;
}

void splitNode(int chave, long int ptrDado, int *pchave, long int *pptrDado, int pos, RegBTree *node, int childRRN, RegBTree **newNode) {
    int median, j;

    if (pos > MIN)
        median = MIN + 1;
    else
        median = MIN;

    *newNode = (RegBTree *)malloc(sizeof(RegBTree));
    (*newNode)->alturaNo = node->alturaNo; // Altura do novo nó é a mesma do nó dividido
    j = median;
    while (j < ORDEM - 1) {
        (*newNode)->chave[j - median] = node->chave[j];
        (*newNode)->ptrDados[j - median] = node->ptrDados[j];
        (*newNode)->filhos[j - median] = node->filhos[j];
        j++;
    }
    (*newNode)->filhos[j - median] = node->filhos[j];
    node->nroChaves = median;
    (*newNode)->nroChaves = ORDEM - 1 - median;

    if (pos <= MIN) {
        insertNode(chave, ptrDado, pos, node, childRRN);
    } else {
        insertNode(chave, ptrDado, pos - median, *newNode, childRRN);
    }
    *pchave = node->chave[node->nroChaves - 1];
    *pptrDado = node->ptrDados[node->nroChaves - 1];
    (*newNode)->filhos[0] = node->filhos[node->nroChaves];
    node->nroChaves--;
}

int setValue(int chave, long int ptrDado, int *pchave, long int *pptrDado, RegBTree *node, int *childRRN, FILE *arquivoIndice, CabecalhoIndexB *cabecalhoIndex) {
    int pos;
    if (node->alturaNo == 0) {
        for (pos = node->nroChaves - 1; (chave < node->chave[pos] && pos >= 0); pos--) {
            node->chave[pos + 1] = node->chave[pos];
            node->ptrDados[pos + 1] = node->ptrDados[pos];
        }
        node->chave[pos + 1] = chave;
        node->ptrDados[pos + 1] = ptrDado;
        node->nroChaves++;
        return (node->nroChaves == ORDEM);
    } else {
        for (pos = node->nroChaves - 1; (chave < node->chave[pos] && pos >= 0); pos--);
        pos++;
    }

    RegBTree *tempNode = (RegBTree *)malloc(sizeof(RegBTree));
    lerNo(arquivoIndice, tempNode, node->filhos[pos]);

    if (setValue(chave, ptrDado, pchave, pptrDado, tempNode, childRRN, arquivoIndice, cabecalhoIndex)) {
        if (node->nroChaves < ORDEM - 1) {
            insertNode(*pchave, *pptrDado, pos, node, *childRRN);
            escreverNo(arquivoIndice, node, cabecalhoIndex->proxRRN++);
            return 0;
        } else {
            RegBTree *newNode;
            splitNode(*pchave, *pptrDado, pchave, pptrDado, pos, node, *childRRN, &newNode);
            escreverNo(arquivoIndice, node, cabecalhoIndex->proxRRN++);
            escreverNo(arquivoIndice, newNode, cabecalhoIndex->proxRRN++);
            *childRRN = cabecalhoIndex->proxRRN - 1;
            return 1;
        }
    }
    free(tempNode);
    return 0;
}

void insert(int chave, long int ptrDado, FILE *arquivoIndice, CabecalhoIndexB *cabecalhoIndex) {
    int pchave, childRRN;
    long int pptrDado;
    RegBTree *root = (RegBTree *)malloc(sizeof(RegBTree));

    if (cabecalhoIndex->noRaiz == -1) {
        root = createNode(chave, ptrDado, -1);
        cabecalhoIndex->noRaiz = cabecalhoIndex->proxRRN++;
        escreverNo(arquivoIndice, root, cabecalhoIndex->noRaiz);
    } else {
        lerNo(arquivoIndice, root, cabecalhoIndex->noRaiz);
        if (setValue(chave, ptrDado, &pchave, &pptrDado, root, &childRRN, arquivoIndice, cabecalhoIndex)) {
            RegBTree *newRoot = createNode(pchave, pptrDado, childRRN);
            newRoot->filhos[0] = cabecalhoIndex->noRaiz;
            newRoot->alturaNo = root->alturaNo + 1; // Aumenta a altura da raiz
            cabecalhoIndex->noRaiz = cabecalhoIndex->proxRRN++;
            escreverNo(arquivoIndice, newRoot, cabecalhoIndex->noRaiz);
        } else {
            escreverNo(arquivoIndice, root, cabecalhoIndex->noRaiz);
        }
    }

    cabecalhoIndex->nroChaves++;
    attCabecalhoB(cabecalhoIndex, arquivoIndice);
    free(root);
}

void search(int chave, int *pos, int rrn, FILE *arquivoIndice) {
    if (rrn == -1) {
        printf("Chave não encontrada.\n");
        return;
    }

    RegBTree *node = (RegBTree *)malloc(sizeof(RegBTree));
    lerNo(arquivoIndice, node, rrn);

    if (chave < node->chave[0]) {
        search(chave, pos, node->filhos[0], arquivoIndice);
    } else {
        for (*pos = node->nroChaves - 1; (*pos >= 0 && chave < node->chave[*pos]); (*pos)--);
        if (*pos >= 0 && chave == node->chave[*pos]) {
            printf("Chave %d encontrada no RRN %d na posição %d\n", chave, rrn, *pos);
            free(node);
            return;
        } else {
            search(chave, pos, node->filhos[*pos + 1], arquivoIndice);
        }
    }
    free(node);
}

void traversal(int rrn, FILE *arquivoIndice) {
    if (rrn != -1) {
        RegBTree *node = (RegBTree *)malloc(sizeof(RegBTree));
        lerNo(arquivoIndice, node, rrn);

        for (int i = 0; i < node->nroChaves; i++) {
            traversal(node->filhos[i], arquivoIndice);
            printf("%d ", node->chave[i]);
        }
        traversal(node->filhos[node->nroChaves], arquivoIndice);
        free(node);
    }
}
