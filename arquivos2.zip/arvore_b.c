#include <stdio.h>
#include <stdlib.h>
#include "arvore_b.h"

void inicializaCabecalhoB(CabecalhoIndexB* c, FILE* arq) {
    c->status = '0';
    c->noRaiz = -1;
    c->proxRRN = 0;
    c->nroChaves = 0;

    fwrite(&c->status, sizeof(char), 1, arq);
    fwrite(&c->noRaiz, sizeof(int), 1, arq);
    fwrite(&c->proxRRN, sizeof(int), 1, arq);
    fwrite(&c->nroChaves, sizeof(int), 1, arq);

    int restoCab = 60 - (3 * sizeof(int) + sizeof(char));
    char lixo = '$';
    for (int i = 0; i < restoCab; i++) {
        fwrite(&lixo, sizeof(char), 1, arq);
    }
}

void attCabecalhoB(CabecalhoIndexB* c, FILE* arq) {
    fseek(arq, 0, SEEK_SET);
    fwrite(&c->status, sizeof(char), 1, arq);
    fwrite(&c->noRaiz, sizeof(int), 1, arq);
    fwrite(&c->proxRRN, sizeof(int), 1, arq);
    fwrite(&c->nroChaves, sizeof(int), 1, arq);
}

void escrevePagina(FILE *arquivo, PaginaB *pagina, int RRN) {
    fseek(arquivo, sizeof(CabecalhoIndexB) + RRN * sizeof(PaginaB), SEEK_SET);
    fwrite(pagina, sizeof(PaginaB), 1, arquivo);
}

void lePagina(FILE *arquivo, PaginaB *pagina, int RRN) {
    fseek(arquivo, sizeof(CabecalhoIndexB) + RRN * sizeof(PaginaB), SEEK_SET);
    fread(pagina, sizeof(PaginaB), 1, arquivo);
}

int buscaPosicao(int chave, int *chaves, int numChaves) {
    int pos = 0;
    while (pos < numChaves && chave > chaves[pos]) {
        pos++;
    }
    return pos;
}

void split(int I_KEY, int I_RRN, PaginaB *pagina, int *PROMO_KEY, int *PROMO_R_CHILD, PaginaB *newPage, int proxRRN) {
    int tempKeys[ORDER];
    int tempPR[ORDER];
    int tempP[ORDER + 1];

    for (int i = 0; i < pagina->numChaves; i++) {
        tempKeys[i] = pagina->chave[i];
        tempPR[i] = pagina->PR[i];
    }
    for (int i = 0; i <= pagina->numChaves; i++) {
        tempP[i] = pagina->P[i];
    }

    int pos = buscaPosicao(I_KEY, tempKeys, pagina->numChaves);
    for (int i = pagina->numChaves; i > pos; i--) {
        tempKeys[i] = tempKeys[i - 1];
        tempPR[i] = tempPR[i - 1];
    }
    tempKeys[pos] = I_KEY;
    tempPR[pos] = I_RRN;

    for (int i = pagina->numChaves + 1; i > pos + 1; i--) {
        tempP[i] = tempP[i - 1];
    }
    tempP[pos + 1] = I_RRN;

    int mid = ORDER / 2;
    *PROMO_KEY = tempKeys[mid];
    *PROMO_R_CHILD = proxRRN;

    pagina->numChaves = mid;
    for (int i = 0; i < mid; i++) {
        pagina->chave[i] = tempKeys[i];
        pagina->PR[i] = tempPR[i];
    }
    for (int i = 0; i <= mid; i++) {
        pagina->P[i] = tempP[i];
    }

    newPage->numChaves = ORDER - mid - 1;
    for (int i = mid + 1, j = 0; i < ORDER; i++, j++) {
        newPage->chave[j] = tempKeys[i];
        newPage->PR[j] = tempPR[i];
    }
    for (int i = mid + 1, j = 0; i <= ORDER; i++, j++) {
        newPage->P[j] = tempP[i];
    }
}

int insert(FILE *arquivo, int CURRENT_RRN, int KEY, int *PROMO_KEY, int *PROMO_R_CHILD, CabecalhoIndexB *cabB) {
    if (CURRENT_RRN == NIL) {
        *PROMO_KEY = KEY;
        *PROMO_R_CHILD = NIL;
        return 1; // PROMOTION
    } else {
        PaginaB pagina;
        lePagina(arquivo, &pagina, CURRENT_RRN);

        int pos = buscaPosicao(KEY, pagina.chave, pagina.numChaves);
        if (pos < pagina.numChaves && KEY == pagina.chave[pos]) {
            return -1; // ERROR
        }

        int PROMO_KEY_CHILD;
        int RETURN_VALUE = insert(arquivo, pagina.P[pos], KEY, &PROMO_KEY_CHILD, PROMO_R_CHILD, cabB);

        if (RETURN_VALUE == 0 || RETURN_VALUE == -1) {
            return RETURN_VALUE;
        } else {
            if (pagina.numChaves < MAX_KEYS) {
                for (int i = pagina.numChaves; i > pos; i--) {
                    pagina.chave[i] = pagina.chave[i - 1];
                    pagina.PR[i] = pagina.PR[i - 1];
                }
                pagina.chave[pos] = PROMO_KEY_CHILD;
                pagina.PR[pos] = *PROMO_R_CHILD;

                for (int i = pagina.numChaves + 1; i > pos + 1; i--) {
                    pagina.P[i] = pagina.P[i - 1];
                }
                pagina.P[pos + 1] = *PROMO_R_CHILD;
                pagina.numChaves++;
                escrevePagina(arquivo, &pagina, CURRENT_RRN);
                return 0; // NO PROMOTION
            } else {
                PaginaB newPage;
                split(PROMO_KEY_CHILD, *PROMO_R_CHILD, &pagina, PROMO_KEY, PROMO_R_CHILD, &newPage, cabB->proxRRN);
                cabB->proxRRN++;
                escrevePagina(arquivo, &pagina, CURRENT_RRN);
                escrevePagina(arquivo, &newPage, *PROMO_R_CHILD);
                return 1; // PROMOTION
            }
        }
    }
}

