#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "funcoes_fornecidas.h"
#include "funcionalidades.h"

//Trabalho Prático 1 - Organização de Arquivos
//Alunos: Gabriel Hyppolito - 14571810, Juan Marques Jordão - 14758742

//main que le a operacao a ser realizada e chama a funcao correspondente com os args necessarios
int main(){
    
    char arg1[30], arg2[30];
    int op=0, n=0;

    scanf("%d", &op);
    scanf("%s", arg1);

    switch(op){
        case 1:
            scanf("%s", arg2);
            createTable(arg1, arg2);
            break;
        case 2:
            selectFrom(arg1);
            break;
        case 3:
            scanf("%d", &n);
            selectWhere(arg1, n);
            break;
        case 4:
            scanf("%s", arg2);
            if(createIndex(arg1, arg2) == 1)
                binarioNaTela(arg2);
            break;
        case 5:
            scanf("%s", arg2);
            scanf("%d", &n);
            if(deleteWhere(arg1, arg2, n) == 1){
                binarioNaTela(arg1);
                binarioNaTela(arg2);
            }
            break;
        case 6:
            scanf("%s", arg2);
            scanf("%d", &n);
            if(insertInto(arg1, arg2, n) == 1){
                binarioNaTela(arg1);
                binarioNaTela(arg2);
            }
            break;
        default:
            break;
    }

    return 0;
}
