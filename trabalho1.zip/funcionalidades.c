#include"funcionalidades.h"
#include"auxiliares.h"
#include"funcoes_fornecidas.h"

//funcao da leitura de dados de um arquivo inicial e escrita dos mesmos em um arquivo binario
//le linhas do arquivo de entrada e as separa em campos, que sao salvos no registro e escritos no arquivo de saida
void createTable(char *entrada, char *saida){
    
    //tentativa de abertura dos nomes dos arquivos recebidos como parametro e saida em caso de erro
    FILE *arquivoEntrada = fopen(entrada, "r");
    if(!abreArquivo(arquivoEntrada))
        return;
    FILE *arquivoSaida = fopen(saida, "wb");
    if(!abreArquivo(arquivoSaida)){
        fclose(arquivoEntrada);
        return;
    }

    //declaracao do registro e cabecalho, com inicializacao e escrita do ultimo no arquivo de saida
    Cabecalho cabecalho;
    Registro registro;
    inicializarCabecalho(&cabecalho);
    escreverCabecalho(&cabecalho, arquivoSaida);

    //limpar primeira linha inutilizavel pro código
    char buffer[45];
    fread(buffer, sizeof(char), 45, arquivoEntrada);

    //variavel teste para armazenar campos e linha para armazenar a linha do arquivo de entrada
    char teste[300], linha[300];

    //loop-while para ler cada linha do arquivo de entrada, extraindo os campos para o registro
    while (fgets(linha, sizeof(linha), arquivoEntrada) != NULL){
        int i=0, j=0;//variaveis para percorrer a linha lida e extrair os campos

        //extraindo o id do jogador
        //armazena o que foi lido da linha em um vet auxiliar ate encontrar uma virgula
        while(linha[i] != ','){
            teste[j] = linha[i];
            i++;
            j++;
        }
        //finaliza a string auxiliar, faz o tratamento do campo lido e salva no registro e pula a virgula e reseta indice do vet aux
        teste[j] = '\0'; 
        registro.id = preencheCampoFixo(teste);
        i++; j=0;

        //extraindo a idade do jogador
        while(linha[i] != ','){
            teste[j] = linha[i];
            i++;
            j++;
        }
        teste[j] = '\0';
        registro.idade = preencheCampoFixo(teste);
        i++; j=0;
        
        //extraindo o nome do jogador
        //nos campos de tam variavel, salva-se o tamcampo e caso nao zero,
        //aloca-se memoria e copia-se o campo pro registro
        while(linha[i] != ','){
            teste[j] = linha[i];
            i++;
            j++;
        }
        teste[j] = '\0';
        registro.tamNomeJog = strlen(teste); 
        if(registro.tamNomeJog == 0){
            registro.nomeJogador = NULL;
        }else{
            registro.nomeJogador = (char *)malloc((registro.tamNomeJog+1) * sizeof(char));
            strcpy(registro.nomeJogador, teste);
        }
        i++; j=0;

        //extraindo a nacionalidade do jogador
        while(linha[i] != ','){
            teste[j] = linha[i];
            i++;
            j++;
        }
        teste[j] = '\0';
        registro.tamNacionalidade = strlen(teste);
        if(registro.tamNacionalidade == 0){
            registro.nacionalidade = NULL;
        }else{
            registro.nacionalidade = (char *)malloc((registro.tamNacionalidade+1) * sizeof(char));
            strcpy(registro.nacionalidade, teste);
        }
        i++; j=0;

        //extraindo o nome do clube do jogador
        //como ultimo campo, le ate final da linha
        while(linha[i] != '\n'){
            teste[j] = linha[i];
            j++;
            i++;
        }
        teste[j] = '\0';
        registro.tamNomeClube = strlen(teste);
        if(registro.tamNomeClube == 0){
            registro.nomeClube = NULL;
        }else{
            registro.nomeClube = (char *)malloc((registro.tamNomeClube+1) * sizeof(char));
            strcpy(registro.nomeClube, teste);
        }
        
        //inicializacao campos registro
        registro.removido = '0';
        registro.Prox = -1;
        registro.tamanhoRegistro = sizeof(int)*6 + sizeof(long int) + sizeof(char)*(registro.tamNomeJog + registro.tamNacionalidade + registro.tamNomeClube + 1);
        
        //escrita do registro lido no arquivo de saida
        escreverRegistro(&registro, arquivoSaida);
        cabecalho.nroRegArq++; //incrementa o numero de registros no arquivo

        //liberando memoria alocada para os campos variaveis
        freeRegistro(&registro);
    }

    //ATUALIZA CABECALHO
    cabecalho.status = '1';
    cabecalho.proxByteOffset = ftell(arquivoSaida); //prox disponivel = prox byte do ultimo campo escrito
    fseek(arquivoSaida, 0, SEEK_SET); //volta pro inicio do arquivo de saida
    escreverCabecalho(&cabecalho, arquivoSaida); //escreve o cabecalho atualizado

    //fecha arquivos usados e chama a funcao binarioNaTela
    fclose(arquivoEntrada);
    fclose(arquivoSaida);
    binarioNaTela(saida);
}

//funcao para leitura de registros de um arquivo binario e impressao dos campos na tela
//abre o arquivo, pega o total de registros e imprime as informacoes principais de cada reg nao removido
void selectFrom(char* arq){
    
    //tentativa de abertura do arquivo binario e retorno em caso de erro
    FILE *arquivo;
    arquivo = fopen(arq, "rb");
    if(!abreArquivo(arquivo))
        return;
    if(!trataStatus(arquivo)){
        fclose(arquivo);
        return;
    }

    //le cabecalho para pegar valores de numero de registros armazenados e removidos
    fseek(arquivo, 0, SEEK_SET);
    Cabecalho cabecalho;
    lerCabecalho(&cabecalho, arquivo);

    //declara registro
    Registro registro;

    //loop para leitura de todos os registros
    for(int i=0; i < cabecalho.nroRegArq+cabecalho.nroRegRem; i++){
        //leitura dos campos 'removido' e 'tamanhoRegistro'
        fread(&registro.removido, sizeof(char), 1, arquivo);
        fread(&registro.tamanhoRegistro, sizeof(int), 1, arquivo);
        if(registro.removido == '0'){ //se nao foi removido
            //traz registro pra memoria principal
            lerRegistro(&registro, arquivo, 0);      

            //impressao dos campos do registro
            //uso de operador ternario para facilitar impressao, se tamCampo = 0, imprime "SEM DADO"
            printf("Nome do Jogador: %s\n", registro.tamNomeJog ? registro.nomeJogador : "SEM DADO");
            printf("Nacionalidade do Jogador: %s\n", registro.tamNacionalidade ? registro.nacionalidade : "SEM DADO");
            printf("Clube do Jogador: %s\n", registro.tamNomeClube ? registro.nomeClube : "SEM DADO");
            printf("\n");

            //libera a memoria alocada para os campos variaveis
            freeRegistro(&registro);
        }else{
            //caso esteja removido, pula para o proximo usando o tamanho do registro
            fseek(arquivo, registro.tamanhoRegistro-5, SEEK_CUR);
        }
    }
    fclose(arquivo);
}

//funcao que realiza uma quantidade n de buscas com parametros especificos no arquivo binario recebido
void selectWhere(char* arqBin, int n) {
    FILE* arquivo = fopen(arqBin, "rb");
    if(!abreArquivo(arquivo))
        return;
    if(!trataStatus(arquivo)){
        fclose(arquivo);
        return;
    }

    //loop para realizar n buscas
    for (int i = 0; i < n; i++) {
        printf("Busca %d\n\n", (i + 1));
        
        //inicializacao de variaveis, garantindo reset de valores a cada busca
        int id = -1, idade = -1, parametros = 0, achou = 0;
        //parametros = numero de parametros da busca, achou = flag para indicar se algum registro foi encontrado
        char nomeJogador[30] = "", nacionalidade[30] = "", nomeClube[30] = "";
        
        //leitura dos parametros de busca
        scanf("%d", &parametros); 
        for (int j = 0; j < parametros; j++) {
            char busca[255];
            scanf("%s", busca);
            if (strcmp(busca, "id") == 0) {
                scanf("%d", &id);
            } else if (strcmp(busca, "idade") == 0) {
                scanf("%d", &idade);
            } else if (strcmp(busca, "nomeJogador") == 0) {
                scan_quote_string(nomeJogador);
            } else if (strcmp(busca, "nacionalidade") == 0) {
                scan_quote_string(nacionalidade);
            } else if (strcmp(busca, "nomeClube") == 0) {
                scan_quote_string(nomeClube);
            }
        }

        //tenta abrir o arquivo e pula para a ler a quantidade de registros armazenados e removidos no arquivo
        //le cabecalho para pegar valores de numero de registros armazenados e removidos
        fseek(arquivo, 0, SEEK_SET);
        Cabecalho cabecalho;
        lerCabecalho(&cabecalho, arquivo);

        Registro registro; 

        //loop para ler todos registros ate fim do arquivo
        for(int i=0; i<cabecalho.nroRegArq+cabecalho.nroRegRem; i++) {
            lerRegistro(&registro, arquivo, 1);

            int valido = 1; //flag para verificar se o registro atende aos parametros de busca

            //cadeia de if's para comparar o registro atual com os parametros
            if (id != -1 && registro.id != id)
                valido = 0;
            if (idade != -1 && registro.idade != idade)
                valido = 0; 
            if (strcmp(nomeJogador, "") != 0 && strcmp(registro.nomeJogador, nomeJogador) != 0)
                valido = 0;
            if (strcmp(nacionalidade, "") != 0 && strcmp(registro.nacionalidade, nacionalidade) != 0)
                valido = 0;
            if (strcmp(nomeClube, "") != 0 && strcmp(registro.nomeClube, nomeClube) != 0)
                valido = 0;

            //se o registro atende parametros e nao esta removido
            if (valido == 1 && registro.removido != '1') {
                printf("Nome do Jogador: %s\n", registro.tamNomeJog ? registro.nomeJogador : "SEM DADO");
                printf("Nacionalidade do Jogador: %s\n", registro.tamNacionalidade ? registro.nacionalidade : "SEM DADO");
                printf("Clube do Jogador: %s\n", registro.tamNomeClube ? registro.nomeClube : "SEM DADO");
                printf("\n");
                achou = 1; //flag para indicar que pelo menos um registro foi encontrado

                //se id foi parametro de busca, nao ha necessidade de continuar
                if(id != -1){
                    break;
                }
            }
            freeRegistro(&registro);//libera memoria alocada para os campos variaveis
        }
        
        //se nenhum registro foi encontrado, imprime a mensagem de erro
        if (achou == 0) {
            printf("Registro inexistente.\n\n");
        }
    }

    fclose(arquivo); 
}

//funcao que cria um arquivo de indice a partir de um arquivo de dados e retorna 1 em caso de sucesso
int createIndex(char *nomedados, char *nomeindex){
    
    //tentaiva de abertura dos arquivos de dados e de indice e retorno em caso de erro ou status inconsistente
    FILE *arqDados = fopen(nomedados, "rb");
    if(!abreArquivo(arqDados))
        return 0;
    if(!trataStatus(arqDados)){
        fclose(arqDados);
        return 0;
    }
    FILE *arqIndex = fopen(nomeindex, "wb");
    if(!abreArquivo(arqIndex)){
        fclose(arqDados);
        fclose(arqIndex);
        return 0;
    }

    //leitura do cabecalho do arquivo de dados
    fseek(arqDados, 0, SEEK_SET);
    Cabecalho cabecalho;
    lerCabecalho(&cabecalho, arqDados);

    //inicializacao do cabecalho do arquivo de indice e escrita
    CabecalhoIndex cabecalhoIndex;
    cabecalhoIndex.status = '0';
    fwrite(&cabecalhoIndex.status, sizeof(char), 1, arqIndex);

    //declaracao dos registros e do vetor de indices
    Registro registro;
    RegistroIndex *indice = (RegistroIndex *)malloc(sizeof(RegistroIndex) * cabecalho.nroRegArq);
    RegistroIndex aux;
    int cont = 0; //variavel auxiliar para controle do vetor de indices

    //define o offset inicial após o cabeçalho
    long int offset = ftell(arqDados);

    //loop para ler todos os registros
    for(int i = 0; i < cabecalho.nroRegArq + cabecalho.nroRegRem; i++){
        
        //leitura dos campos 'removido' e 'tamanhoRegistro' e atualizacao do offset atual
        fread(&registro.removido, sizeof(char), 1, arqDados);
        fread(&registro.tamanhoRegistro, sizeof(int), 1, arqDados);
        offset = ftell(arqDados) - sizeof(char) - sizeof(int);

        //se o registro nao foi removido traz pra mem. principal e insere no vetor de indices
        if(registro.removido == '0'){
            lerRegistro(&registro, arqDados, 0);
            aux.id = registro.id;
            aux.byteoffset = offset;
            inserirIndice(indice, &cont, aux);

            //declaracao de um offset auxiliar para garantir o pulo correto para o proximo registro
            //necessario para casos de reaproveitamento de espaco, onde ha preenchimento com '$'
            long int finalOffset = offset + registro.tamanhoRegistro;
            fseek(arqDados, finalOffset, SEEK_SET);
        } else {

            //caso o registro esteja removido, pula para o proximo registro
            fseek(arqDados, registro.tamanhoRegistro - (sizeof(char) + sizeof(int)), SEEK_CUR);
        }

        freeRegistro(&registro);
    }

    //apos a leitura de todos os registros, escreve o indice no arquivo de indice
    escreveIndex(arqIndex, indice, cont);

    //atualizacao do status do arquivo de indice
    cabecalhoIndex.status = '1';
    fseek(arqIndex, 0, SEEK_SET);
    fwrite(&cabecalhoIndex.status, sizeof(char), 1, arqIndex);

    fclose(arqDados);
    fclose(arqIndex);
    free(indice);

    return 1;
}

//funcao que deleta registros de um arquivo de dados a partir de parametros de busca e atualiza o arquivo de indice
int deleteWhere(char *arq, char *index, int n){
    
    //abre o arquivo de dados e verifica se o status esta consistente
    FILE *arqDados = fopen(arq, "r+b");
    if(!abreArquivo(arqDados))
        return 0;
    if(!trataStatus(arqDados)){
        fclose(arqDados);
        return 0;
    }

    //abre o arquivo de indice e chama a funcao de criacao do indice
    FILE *arqIndex = fopen(index, "w+b");
    if(!abreArquivo(arqIndex)){
        fclose(arqDados);
        return 0;
    }
    createIndex(arq, index);

    //criar um novo arquivo temporario para atualizar o indice
    FILE *tmpIndex = fopen("temp_index.bin", "wb");
    if (!abreArquivo(tmpIndex)) {
        fclose(arqDados);
        fclose(arqIndex);
        return 0;
    }
    
    //leitura do cabecalho do arquivo de dados e atualizacao do status
    Cabecalho cabecalho;
    fseek(arqDados, 0, SEEK_SET);
    lerCabecalho(&cabecalho, arqDados);
    cabecalho.status = '0';

    //traz o arquivo de indice para a memoria principal
    CabecalhoIndex cabecalhoIndex;
    RegistroIndex *indice = (RegistroIndex *)malloc(sizeof(RegistroIndex)*cabecalho.nroRegArq);
    int cont=0;
    leIndice(indice, arqIndex, cabecalhoIndex, &cont);

    //cria uma lista para os registros removidos e inicializa com os registros marcados como removidos do arquivo de dados
    LISTA *removidos = criaLista();
    inicializaLista(removidos, arqDados, cabecalho.topo);

    //loop para realizar n buscas
    for(int i=0; i<n; i++){

        //inicializacao de variaveis, garantindo reset de valores a cada busca
        int id=-1, idade=-1, parametros=0;
        char nomeJogador[30] = "", nacionalidade[30] = "", nomeClube[30] = "";

        //leitura dos parametros de busca
        scanf("%d", &parametros);
        for(int j=0; j<parametros; j++){
            char busca[255];
            scanf("%s", busca);
            if (strcmp(busca, "id") == 0) {
                scanf("%d", &id);
            } else if (strcmp(busca, "idade") == 0) {
                scanf("%d", &idade);
            } else if (strcmp(busca, "nomeJogador") == 0) {
                scan_quote_string(nomeJogador);
            } else if (strcmp(busca, "nacionalidade") == 0) {
                scan_quote_string(nacionalidade);
            } else if (strcmp(busca, "nomeClube") == 0) {
                scan_quote_string(nomeClube);
            }
        }
        
        //se id foi parametro de busca, procura no indice
        if(id != -1){

            //busca sequencial no indice pelo id
            for(int j=0; j<cont; j++){

                //se o id foi encontrado no indice, insere na lista e remove logicamente do arquivo de dados
                if(indice[j].id == id){
                    long int offset = indice[j].byteoffset;
                    fseek(arqDados, offset, SEEK_SET);
                    
                    Registro reg;
                    fread(&reg.removido, sizeof(char), 1, arqDados);
                    fread(&reg.tamanhoRegistro, sizeof(int), 1, arqDados);
                    if(reg.removido == '0'){
                        lerRegistro(&reg, arqDados, 0);

                        insereOrdenado(removidos, offset, reg.tamanhoRegistro);

                        //atualiza no arquivo de dados
                        reg.removido = '1';
                        reg.Prox = getOffsetProx(removidos, offset);
                        fseek(arqDados, offset, SEEK_SET);
                        escreverRegistro(&reg, arqDados);

                        //atualiza o campo `prox` do registro removido anterior no arquivo de dados
                        NO *atual = removidos->cabeca;
                        while (atual != NULL && atual->prox != NULL){
                            if (atual->prox->offset == offset) {
                                long int posAnterior = atual->offset;
                                Registro regAnterior;
                                fseek(arqDados, posAnterior, SEEK_SET);
                                lerRegistro(&regAnterior, arqDados, 1);
                                regAnterior.Prox = offset;
                                fseek(arqDados, posAnterior, SEEK_SET);
                                escreverRegistro(&regAnterior, arqDados);
                                freeRegistro(&regAnterior);
                                break;
                            }
                                atual = atual->prox;
                            }

                        cabecalho.nroRegArq--;
                        cabecalho.nroRegRem++;
                        
                        freeRegistro(&reg);
                    }else{
                        break;
                    }
                    break;
                }
            }
        }else{
            
            //se id nao e parametro de busca, busca sequencial no arquivo de dados

            //pula cabecalho e declaracao de variaveis
            fseek(arqDados, 25, SEEK_SET);
            Registro registro;
            long int offset;

            //loop para leitura de todos os registros
            for(int k=0; k<cabecalho.nroRegArq+cabecalho.nroRegRem; k++){
                
                //atualizacao offset e leitura campos
                offset = ftell(arqDados);
                fread(&registro.removido, sizeof(char), 1, arqDados);
                fread(&registro.tamanhoRegistro, sizeof(int), 1, arqDados);
                
                //se nao removido, compara com os parametros de busca
                if(registro.removido == '0'){
                    lerRegistro(&registro, arqDados, 0);
                    int valido=1;
                    if (id != -1 && registro.id != id)
                        valido = 0;
                    if (idade != -1 && registro.idade != idade)
                        valido = 0;
                    if (strcmp(nomeJogador, "") != 0 && strcmp(registro.nomeJogador, nomeJogador) != 0)
                        valido = 0;
                    if (strcmp(nacionalidade, "") != 0 && strcmp(registro.nacionalidade, nacionalidade) != 0)
                        valido = 0;
                    if (strcmp(nomeClube, "") != 0 && strcmp(registro.nomeClube, nomeClube) != 0)
                        valido = 0;
                    
                    //se o registro atende aos parametros, insere na lista e remove logicamente do arquivo de dados
                    if(valido){
                        insereOrdenado(removidos, offset, registro.tamanhoRegistro);

                        //atualiza no arquivo de dados
                        registro.removido = '1';
                        registro.Prox = getOffsetProx(removidos, offset);
                        fseek(arqDados, offset, SEEK_SET);
                        escreverRegistro(&registro, arqDados);

                        //atualiza o removido anterior no arquivo de dados
                        NO *atual = removidos->cabeca;
                        while(atual != NULL && atual->prox != NULL){
                            if(atual->prox->offset == offset){
                                long int posAnterior = atual->offset;
                                Registro regAnterior;
                                fseek(arqDados, posAnterior, SEEK_SET);
                                lerRegistro(&regAnterior, arqDados, 1);
                                regAnterior.Prox = offset;

                                fseek(arqDados, posAnterior, SEEK_SET);
                                escreverRegistro(&regAnterior, arqDados);
                                freeRegistro(&regAnterior);
                                break;
                            }
                            atual = atual->prox;
                        }

                        cabecalho.nroRegArq--;
                        cabecalho.nroRegRem++;

                        //pula para o proximo registro
                        fseek(arqDados, offset+registro.tamanhoRegistro, SEEK_SET);
                    }
                    freeRegistro(&registro);
                }else{
                    fseek(arqDados, registro.tamanhoRegistro-5, SEEK_CUR);
                }
            }
        }
    }

    //atualizacao do cabecalho do arquivo de dados
    cabecalho.status = '1';
    cabecalho.topo = getTopo(removidos);
    fseek(arqDados, 0, SEEK_SET);
    escreverCabecalho(&cabecalho, arqDados);
    fclose(arqDados);
    
    //atualizacao do arquivo de indice
    createIndex(arq, "temp_index.bin");
    remove(index);
    rename("temp_index.bin", index);

    fclose(arqIndex);

    //liberacao de memoria alocada
    liberarLista(removidos);

    return 1;
}

//funcao que insere registros em um arquivo de dados a partir de parametros de entrada e atualiza o arquivo de indice
int insertInto(char *arq, char *index, int n) {
    
    //abre o arquivo de dados e verifica se o status esta consistente
    FILE *arqDados = fopen(arq, "r+b");
    if (!abreArquivo(arqDados))
        return 0;
    if (!trataStatus(arqDados)) {
        fclose(arqDados);
        return 0;
    }

    //abre o arquivo de indice e chama a funcao de criacao do indice no estado atual
    FILE *arqIndex = fopen(index, "w+b");
    if (!abreArquivo(arqIndex)) {
        fclose(arqDados);
        return 0;
    }
    createIndex(arq, index);

    //criar um novo arquivo temporario para atualizar o indice
    FILE *tmpIndex = fopen("temp_index.bin", "wb");
    if (!abreArquivo(tmpIndex)) {
        fclose(arqDados);
        fclose(arqIndex);
        return 0;
    }

    //leitura do cabecalho do arquivo de dados e atualizacao do status
    Cabecalho cabecalho;
    fseek(arqDados, 0, SEEK_SET);
    lerCabecalho(&cabecalho, arqDados);
    cabecalho.status = '0';

    //criacao da lista de registros removidos e inicializacao com os registros marcados como removidos do arquivo de dados
    LISTA *removidos = criaLista();
    inicializaLista(removidos, arqDados, cabecalho.topo);

    //loop para realizar n insercoes
    for (int i = 0; i < n; i++) {

        //inicializacao de variaveis, garantindo reset de valores a cada insercao
        int id = -1, idade = -1, tamNomeJog = 0, tamNacionalidade = 0, tamNomeClube = 0;
        char leID[10] = "", leIdade[10] = "", nomeJogador[30] = "", nacionalidade[30] = "", nomeClube[30] = "";

        //leitura dos campos do registro a ser inserido
        scan_quote_string(leID);
        if (strcmp(leID, "") != 0) {
            id = atoi(leID);
        }
        scan_quote_string(leIdade);
        if (strcmp(leIdade, "") != 0) {
            idade = atoi(leIdade);
        }
        scan_quote_string(nomeJogador);
        if (strcmp(nomeJogador, "") != 0) {
            tamNomeJog = strlen(nomeJogador);
        }
        scan_quote_string(nacionalidade);
        if (strcmp(nacionalidade, "") != 0) {
            tamNacionalidade = strlen(nacionalidade);
        }
        scan_quote_string(nomeClube);
        if (strcmp(nomeClube, "") != 0) {
            tamNomeClube = strlen(nomeClube);
        }

        fseek(arqDados, 0, SEEK_SET);

        //declara registro e inicializa com os campos lidos
        Registro registro;
        inicializaRegistro(&registro, id, idade, tamNomeJog, nomeJogador, tamNacionalidade, nacionalidade, tamNomeClube, nomeClube);

        //tamanho necessario para o registro a ser buscado na lista de removidos
        int tamNecessario = 6 * sizeof(int) + sizeof(long int) + sizeof(char) * (tamNomeJog + tamNacionalidade + tamNomeClube + 1);
        
        //se nao ha registros removidos, insere novo registro no final do arquivo de dados
        if (cabecalho.topo == -1) {
            fseek(arqDados, cabecalho.proxByteOffset, SEEK_SET);
            registro.tamanhoRegistro = tamNecessario;
            escreverRegistro(&registro, arqDados);
            cabecalho.proxByteOffset += tamNecessario;
            cabecalho.nroRegArq++;
        } else {

            //se ha registros removidos, busca o melhor espaco para inserir o novo registro
            NO *melhor = bestFit(removidos, tamNecessario);

            if (melhor != NULL) {

                //se existe o o espaco necessario, reescreve no offset do registro removido, mantendo o tamanho original
                fseek(arqDados, melhor->offset, SEEK_SET);
                registro.tamanhoRegistro = melhor->tamReg;
                escreverRegistro(&registro, arqDados);

                //se o espaco disponivel for maior que o necessario, preenche o restante com '$'
                if (melhor->tamReg > tamNecessario) {
                    int espacoRestante = melhor->tamReg - tamNecessario;
                    fseek(arqDados, melhor->offset + tamNecessario, SEEK_SET);
                    for (int j = 0; j < espacoRestante; j++) {
                        fwrite("$", sizeof(char), 1, arqDados);
                    }
                }

                //atualiza o campo `prox` do registro anterior ao reaproveitado
                NO *anterior = removidos->cabeca;
                while (anterior != NULL && anterior->prox != melhor) {
                    anterior = anterior->prox;
                }
                if (anterior != NULL) {
                    anterior->prox = melhor->prox;

                    fseek(arqDados, anterior->offset, SEEK_SET);
                    Registro regAnterior;
                    lerRegistro(&regAnterior, arqDados, 1);
                    if(anterior->prox != NULL)
                        regAnterior.Prox = anterior->prox->offset;
                    else
                        regAnterior.Prox = -1;
                    fseek(arqDados, anterior->offset, SEEK_SET);
                    escreverRegistro(&regAnterior, arqDados);
                    freeRegistro(&regAnterior);
                }

                cabecalho.nroRegArq++;
                cabecalho.nroRegRem--;

                //libera a memoria alocada para o registro removido
                NO *removido = removeLista(removidos, melhor);
                if (removido != NULL) {
                    free(removido);
                }
            } else {

                //se nao ha espaco disponivel, insere no final do arquivo de dados
                fseek(arqDados, cabecalho.proxByteOffset, SEEK_SET);
                registro.tamanhoRegistro = tamNecessario;
                escreverRegistro(&registro, arqDados);
                cabecalho.proxByteOffset += tamNecessario;
                cabecalho.nroRegArq++;
            }
        }
        freeRegistro(&registro);
    }

    //atualizacao do cabecalho do arquivo de dados
    cabecalho.topo = getTopo(removidos);
    cabecalho.status = '1';
    fseek(arqDados, 0, SEEK_SET);
    escreverCabecalho(&cabecalho, arqDados);
    fclose(arqDados);

    //atualizacao do arquivo de indice
    createIndex(arq, "temp_index.bin");
    remove(index);
    rename("temp_index.bin", index);

    fclose(arqIndex);
    liberarLista(removidos);

    return 1;
}

