#ifndef LISTA_REMOVIDOS_H
#define LISTA_REMOVIDOS_H

#include<stdio.h>
#include<stdlib.h>

//estrutura de um no da lista
typedef struct no{
    long int offset;
    int tamReg;
    struct no *prox;
}NO;

//estrutura da lista
typedef struct lista{
    NO *cabeca;
}LISTA;

LISTA *criaLista();
void inicializaLista(LISTA *l, FILE *arqdados, long int topo);
void insereOrdenado(LISTA *l, long int offset, int tamReg);
NO* removeLista(LISTA *l, NO *no);
NO *bestFit(LISTA *l, int tamReg);
void liberarLista(LISTA *l);
long int getOffsetProx(LISTA *l, long int offset);
long int getTopo(LISTA *l);
void imprimeLista(LISTA *l);

#endif