#ifndef AUXILIARES_H
#define AUXILIARES_H

#include <string.h>
#include <stdbool.h>
#include <string.h>
#include <stdbool.h>
#include "funcoes_fornecidas.h"
#include "lista.h"

typedef struct{
    char status;
    long int topo, proxByteOffset;
    int nroRegArq, nroRegRem;
}Cabecalho;

typedef struct{
    int id, idade, tamanhoRegistro, tamNomeJog, tamNacionalidade, tamNomeClube;
    long int Prox;
    char removido, *nomeJogador, *nacionalidade, *nomeClube;
}Registro;

typedef struct{
    char status;
}CabecalhoIndex;

typedef struct{
    int id;
    long int byteoffset;
}RegistroIndex;



bool abreArquivo(FILE *arquivo);
void inicializarCabecalho(Cabecalho *cabecalho);
void escreverCabecalho(Cabecalho *cabecalho, FILE *arquivo);
void lerCabecalho(Cabecalho *cabecalho, FILE *arquivo);
void lerRegistro(Registro *registro, FILE *arquivo, int filtro);
void escreverRegistro(Registro *registro, FILE *arquivo);
void inicializaRegistro(Registro *registro, int id, int idade, int tamNomeJog, char *nomeJog, int tamNacionalidade, char *nacionalidade, int tamNomeClube, char *nomeClube);
int preencheCampoFixo(char *campo);
bool trataStatus(FILE *arquivo);
void inserirIndice(RegistroIndex *indice, int *cont, RegistroIndex aux);
void escreveIndex(FILE *arqIndex, RegistroIndex *indice, int cont);
void freeRegistro(Registro *registro);
void leIndice(RegistroIndex *indice, FILE *arqindex, CabecalhoIndex cabecalho, int *cont);

#endif