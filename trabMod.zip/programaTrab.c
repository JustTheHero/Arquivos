#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "funcoes_fornecidas.h"

//Trabalho Prático 1 - Organização de Arquivos
//Alunos: Gabriel Hyppolito - 14571810, Juan Marques Jordão - 14758742

//definicao das structs de registro e cabecalho segundo especificado

//funcao da leitura de dados de um arquivo inicial e escrita dos mesmos em um arquivo binario
//le linhas do arquivo de entrada e as separa em campos, que sao salvos no registro e escritos no arquivo de saida

int main(){
    //main que le a operacao a ser realizada e chama a funcao correspondente com os args necessarios
    char arg1[30], arg2[30];
    int op=0, n=0;

    scanf("%d", &op);
    scanf("%s", arg1);

    switch(op){
        case 1:
            scanf("%s", arg2);
            createTable(arg1, arg2);
            break;
        case 2:
            selectFrom(arg1);
            break;
        case 3:
            scanf("%d", &n);
            selectWhere(arg1, n);
            break;
        case 4:
            scanf("%s", arg2);
            if(createIndex(arg1, arg2) == 1)
                binarioNaTela(arg2);
            break;
        case 5:
            scanf("%s", arg2);
            scanf("%d", &n);
            if(deleteWhere(arg1, arg2, n) == 1){
                binarioNaTela(arg1);
                binarioNaTela(arg2);
            }
            break;
        case 6:
            scanf("%s", arg2);
            scanf("%d", &n);
            if(insertInto(arg1, arg2, n) == 1){
                binarioNaTela(arg1);
                binarioNaTela(arg2);
            }
            break;
        default:
            break;
    }

    return 0;
}
