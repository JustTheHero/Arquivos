#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "funcoes_fornecidas.h"

//Trabalho Prático - Organização de Arquivos
//Alunos: Gabriel Hyppolito - 14571810, Juan Marques Jordão - 14758742

//definicao das structs de registro e cabecalho segundo especificado
typedef struct{
    char status;
    long int topo, proxByteOffset;
    int nroRegArq, nroRegRem;
}Cabecalho;

typedef struct{
    int id, idade, tamanhoRegistro, tamNomeJog, tamNacionalidade, tamNomeClube;
    long int Prox;
    char removido, *nomeJogador, *nacionalidade, *nomeClube;
}Registro;

//funcao chamada para definir o estado inicial do cabeçalho
void inicializarCabecalho(Cabecalho *cabecalho){
    cabecalho->status = '0';
    cabecalho->topo = -1;
    cabecalho->proxByteOffset = 0;
    cabecalho->nroRegArq = 0;
    cabecalho->nroRegRem = 0;
}

//funcao chamada para escrita do cabecalho no arquivo de saida
void escreverCabecalho(Cabecalho *cabecalho, FILE *arquivo){
    fwrite(&cabecalho->status, sizeof(char), 1, arquivo);
    fwrite(&cabecalho->topo, sizeof(long int), 1, arquivo);
    fwrite(&cabecalho->proxByteOffset, sizeof(long int), 1, arquivo);
    fwrite(&cabecalho->nroRegArq, sizeof(int), 1, arquivo);
    fwrite(&cabecalho->nroRegRem, sizeof(int), 1, arquivo);
}

//funcao usada pra ler campos de um arquivo binario recebido e salva-los na mem. principal para uso
void lerRegistro(Registro *registro, FILE *arquivo){
            
            //nao contem a leitura dos campos 'removido' e 'tamanhoRegistro' pois na logica de leitura do arquivo
            //da funcao selectFrom esses campos sao lidos anteriormente, a fim de evitar acessos desnecessarios
            //caso um registro esteja marcado como removido
            fread(&registro->Prox, sizeof(long int), 1, arquivo);
            fread(&registro->id, sizeof(int), 1, arquivo);
            fread(&registro->idade, sizeof(int), 1, arquivo);
            fread(&registro->tamNomeJog, sizeof(int), 1, arquivo);
            registro->nomeJogador = (char *)malloc((registro->tamNomeJog) * sizeof(char));
            fread(registro->nomeJogador, sizeof(char), registro->tamNomeJog, arquivo);
            registro->nomeJogador[registro->tamNomeJog] = '\0';
            fread(&registro->tamNacionalidade, sizeof(int), 1, arquivo);
            registro->nacionalidade = (char *)malloc((registro->tamNacionalidade) * sizeof(char));
            fread(registro->nacionalidade, sizeof(char), registro->tamNacionalidade, arquivo);
            registro->nacionalidade[registro->tamNacionalidade] = '\0';
            fread(&registro->tamNomeClube, sizeof(int), 1, arquivo);
            registro->nomeClube = (char *)malloc((registro->tamNomeClube) * sizeof(char));
            fread(registro->nomeClube, sizeof(char), registro->tamNomeClube, arquivo);
            registro->nomeClube[registro->tamNomeClube] = '\0';
}

//funcao com a mesma funcionalidade da anterior, porem usada na logica da funcao selectWhere, contem a leitura
//dos campos 'removido' e 'tamanhoRegistro'
void lerRegistro2(Registro *registro, FILE *arquivo){
            fread(&registro->removido, sizeof(char), 1, arquivo);
            fread(&registro->tamanhoRegistro, sizeof(int), 1, arquivo);
            fread(&registro->Prox, sizeof(long int), 1, arquivo);
            fread(&registro->id, sizeof(int), 1, arquivo);
            fread(&registro->idade, sizeof(int), 1, arquivo);
            fread(&registro->tamNomeJog, sizeof(int), 1, arquivo);
            registro->nomeJogador = (char *)malloc((registro->tamNomeJog+1) * sizeof(char));
            fread(registro->nomeJogador, sizeof(char), registro->tamNomeJog, arquivo);
            fread(&registro->tamNacionalidade, sizeof(int), 1, arquivo);
            registro->nacionalidade = (char *)malloc((registro->tamNacionalidade+1) * sizeof(char));
            fread(registro->nacionalidade, sizeof(char), registro->tamNacionalidade, arquivo);
            fread(&registro->tamNomeClube, sizeof(int), 1, arquivo);
            registro->nomeClube = (char *)malloc((registro->tamNomeClube+1) * sizeof(char));
            fread(registro->nomeClube, sizeof(char), registro->tamNomeClube, arquivo);
}

//funcao usada para escrever um registro salvo na memoria principal no arquivo de saida, campo a campo
void escreverRegistro(Registro *registro, FILE *arquivo){
    fwrite(&registro->removido, sizeof(char), 1, arquivo);
    fwrite(&registro->tamanhoRegistro, sizeof(int), 1, arquivo);
    fwrite(&registro->Prox, sizeof(long int), 1, arquivo);
    fwrite(&registro->id, sizeof(int), 1, arquivo);
    fwrite(&registro->idade, sizeof(int), 1, arquivo);
    fwrite(&registro->tamNomeJog, sizeof(int), 1, arquivo);
    fwrite(registro->nomeJogador, registro->tamNomeJog, 1, arquivo);
    fwrite(&registro->tamNacionalidade, sizeof(int), 1, arquivo);
    fwrite(registro->nacionalidade, registro->tamNacionalidade, 1, arquivo);
    fwrite(&registro->tamNomeClube, sizeof(int), 1, arquivo);
    fwrite(registro->nomeClube, registro->tamNomeClube, 1, arquivo);
}

//funcao para preencher os campos id e idade do registro a partir da string obtida pela 
//logica de leitura dos dados do arquivo de entrada
int preencheCampoFixo(char *campo){
    if(strlen(campo) == 0)
        return -1;
    else
        return atoi(campo);
}

//funcao que libera a memoria alocada para os campos de tamanho variavel do registro
void freeRegistro(Registro *registro){
     registro->nomeClube = NULL;
     registro->nacionalidade = NULL;
     registro->nomeJogador = NULL;
     free(registro->nomeClube);
     free(registro->nacionalidade);
     free(registro->nomeJogador);
}

//funcao da leitura de dados de um arquivo inicial e escrita dos mesmos em um arquivo binario
void createTable(char *entrada, char *saida){
    FILE *arquivoEntrada = fopen(entrada, "r");
    if(arquivoEntrada == NULL){
        printf("Falha no processamento do arquivo.\n");
        fclose(arquivoEntrada);
        return;
    }
    FILE *arquivoSaida = fopen(saida, "wb");
    if(arquivoSaida == NULL){
        printf("Falha no processamento do arquivo.\n");
        fclose(arquivoSaida);
        return;
    }
    //tentativa de abertura dos nomes dos arquivos recebidos como parametro e saida em caso de erro

    Cabecalho cabecalho;
    Registro registro;
    inicializarCabecalho(&cabecalho);
    escreverCabecalho(&cabecalho, arquivoSaida);
    //declaracao do registro e cabecalho, com inicializacao e escrita do ultimo no arquivo de saida

    char buffer[45];
    fread(buffer, sizeof(char), 45, arquivoEntrada);
    //limpar primeira linha inutilizavel pro código

    char teste[300], linha[300];

    while (fgets(linha, sizeof(linha), arquivoEntrada) != NULL){
        //loop-while para ler cada linha do arquivo de entrada, extraindo os campos para o registro
        int i=0, j=0;//variaveis para percorrer a linha lida e extrair os campos

        //extraindo o id do jogador
        while(linha[i] != ','){
            //armazena o que foi lido da linha em um vet auxiliar ate encontrar uma virgula
            teste[j] = linha[i];
            i++;
            j++;
        }
        teste[j] = '\0'; //finaliza a string auxiliar
        registro.id = preencheCampoFixo(teste); //faz o tratamento do campo lido e salva no registro
        i++; j=0; //pula a virgula e reseta indice do vet aux

        //extraindo a idade do jogador
        while(linha[i] != ','){
            teste[j] = linha[i];
            i++;
            j++;
        }
        teste[j] = '\0';
        registro.idade = preencheCampoFixo(teste);
        i++; j=0;
        //extraindo o nome do jogador
        while(linha[i] != ','){
            teste[j] = linha[i];
            i++;
            j++;
        }
        teste[j] = '\0';
        //nos campos de tam variavel, salva-se o tamcampo e caso nao zero,
        //aloca-se memoria e copia-se o campo pro registro
        registro.tamNomeJog = strlen(teste); 
        if(registro.tamNomeJog == 0){
            registro.nomeJogador = NULL;
        }else{
            registro.nomeJogador = (char *)malloc((registro.tamNomeJog+1) * sizeof(char));
            strcpy(registro.nomeJogador, teste);
        }
        i++; j=0;
        //extraindo a nacionalidade do jogador
        while(linha[i] != ','){
            teste[j] = linha[i];
            i++;
            j++;
        }
        teste[j] = '\0';
        registro.tamNacionalidade = strlen(teste);
        if(registro.tamNacionalidade == 0){
            registro.nacionalidade = NULL;
        }else{
            registro.nacionalidade = (char *)malloc((registro.tamNacionalidade+1) * sizeof(char));
            strcpy(registro.nacionalidade, teste);
        }
        i++; j=0;
        //extraindo o nome do clube do jogador
        //como ultimo campo, le ate final da linha
        while(linha[i] != '\n'){
            teste[j] = linha[i];
            j++;
            i++;
        }
        teste[j] = '\0';
        registro.tamNomeClube = strlen(teste);
        if(registro.tamNomeClube == 0){
            registro.nomeClube = NULL;
        }else{
            registro.nomeClube = (char *)malloc((registro.tamNomeClube+1) * sizeof(char));
            strcpy(registro.nomeClube, teste);
        }
        
        //inicializacao campos registro
        registro.removido = '0';
        registro.Prox = -1;
        registro.tamanhoRegistro = sizeof(int)*6 + sizeof(long int) + sizeof(char)*(registro.tamNomeJog + 
                                    registro.tamNacionalidade + registro.tamNomeClube + 1);
        
        //escrita do registro lido no arquivo de saida
        escreverRegistro(&registro, arquivoSaida);
        cabecalho.nroRegArq++; //incrementa o numero de registros no arquivo

        //liberando memoria alocada para os campos variaveis
        freeRegistro(&registro);
    }

    //ATUALIZA CABECALHO
    cabecalho.status = '1';
    cabecalho.proxByteOffset = ftell(arquivoSaida); //prox disponivel = prox byte do ultimo campo escrito
    fseek(arquivoSaida, 0, SEEK_SET); //volta pro inicio do arquivo de saida
    escreverCabecalho(&cabecalho, arquivoSaida); //escreve o cabecalho atualizado

    //fecha arquivos usados e chama a funcao binarioNaTela
    fclose(arquivoEntrada);
    fclose(arquivoSaida);

    binarioNaTela(saida);
}

//funcao para leitura de registros de um arquivo binario e impressao dos campos na tela
void selectFrom(char* arq){
    FILE *arquivo;
    arquivo = fopen(arq, "rb");
    if(arquivo == NULL){
        printf("Falha no processamento do arquivo.\n");
        return;
    }

    //tenta abrir o arquivo e pula para a ler a quantidade de registros armazenados e removidos no arquivo
    fseek(arquivo, 17, SEEK_SET);
    int nroRegArq, nroRegRem;
    fread(&nroRegArq, sizeof(int), 1, arquivo);
    fread(&nroRegRem, sizeof(int), 1, arquivo);

    //se nao ha registros nao removidos no arquivo, imprime o erro e retorna
    if(nroRegArq == 0){
            printf("Registro inexistente.\n");
            printf("\n");
            fclose(arquivo);
            return;
        }

    //declara registro
    Registro registro;
    fseek(arquivo, 25, SEEK_SET);//pula o cabecalho e vai para o primeiro registro
    for(int i=0; i < nroRegArq+nroRegRem; i++){//loop para leitura de todos os registros
        //leitura dos campos 'removido' e 'tamanhoRegistro'
        fread(&registro.removido, sizeof(char), 1, arquivo);
        fread(&registro.tamanhoRegistro, sizeof(int), 1, arquivo);
        if(registro.removido == '0'){ //se nao foi removido
            //imprimir o registro
            lerRegistro(&registro, arquivo);      

            //impressao dos campos do registro
            //uso de operador ternario para facilitar impressao, se tamCampo = 0, imprime "SEM DADO"
            printf("Nome do Jogador: %s\n", registro.tamNomeJog ? registro.nomeJogador : "SEM DADO");
            printf("Nacionalidade do Jogador: %s\n", registro.tamNacionalidade ? registro.nacionalidade : "SEM DADO");
            printf("Clube do Jogador: %s\n", registro.tamNomeClube ? registro.nomeClube : "SEM DADO");
            printf("\n");

            freeRegistro(&registro); //libera a memoria alocada para os campos variaveis
        }else{
            //caso esteja removido, retorna para o inicio do registro e pula para o proximo usando o tamanho do registro
            fseek(arquivo, -5, SEEK_CUR);
            fseek(arquivo, registro.tamanhoRegistro, SEEK_CUR);
        }
    }
    fclose(arquivo);
}

//funcao que realiza uma quantidade n de buscas com parametros especificos no arquivo binario recebido
void selectWhere(char* arqBin, int n) {
    FILE* arquivo = fopen(arqBin, "rb");
    if (arquivo == NULL) {
        printf("Falha no processamento do arquivo.\n");
        return;
    }

    //loop para realizar n buscas
    for (int i = 0; i < n; i++) {
        printf("Busca %d\n\n", (i + 1));
        //inicializacao de variaveis, garantindo reset de valores a cada busca
        int id = -1, idade = -1, parametros = 0, achou = 0;
        char nomeJogador[30] = "", nacionalidade[30] = "", nomeClube[30] = "";
        
        //leitura dos parametros de busca
        scanf("%d", &parametros); 
        for (int j = 0; j < parametros; j++) {
            char busca[255];
            scanf("%s", busca);
            if (strcmp(busca, "id") == 0) {
                scanf("%d", &id);
            } else if (strcmp(busca, "idade") == 0) {
                scanf("%d", &idade);
            } else if (strcmp(busca, "nomeJogador") == 0) {
                scan_quote_string(nomeJogador);
            } else if (strcmp(busca, "nacionalidade") == 0) {
                scan_quote_string(nacionalidade);
            } else if (strcmp(busca, "nomeClube") == 0) {
                scan_quote_string(nomeClube);
            }
        }

        //pula o cabecalho do arquivo e declara o registro para salvar os dados lidos
        fseek(arquivo, 25, SEEK_SET); 
        Registro registro; 

        while (!feof(arquivo)) {
            //loop para ler todos registros ate fim do arquivo
            lerRegistro2(&registro, arquivo);

            int valido = 1; //flag para verificar se o registro atende aos parametros de busca

            //cadeia de if's para comparar o registro atual com os parametros
            if (id != -1 && registro.id != id)
                valido = 0;
            if (idade != -1 && registro.idade != idade)
                valido = 0; 
            if (strcmp(nomeJogador, "") != 0 &&strcmp(registro.nomeJogador, nomeJogador) != 0)
                valido = 0;
            if (strcmp(nacionalidade, "") != 0 && strcmp(registro.nacionalidade, nacionalidade) != 0)
                valido = 0;
            if (strcmp(nomeClube, "") != 0 && strcmp(registro.nomeClube, nomeClube) != 0)
                valido = 0;

            if (valido == 1 && registro.removido != '1') { //se o registro atende parametros e nao esta removido
                printf("Nome do Jogador: %s\n", registro.tamNomeJog ? registro.nomeJogador : "SEM DADO");
                printf("Nacionalidade do Jogador: %s\n", registro.tamNacionalidade ? registro.nacionalidade : "SEM DADO");
                printf("Clube do Jogador: %s\n", registro.tamNomeClube ? registro.nomeClube : "SEM DADO");
                printf("\n");
                achou = 1; //flag para indicar que pelo menos um registro foi encontrado
            }
            freeRegistro(&registro);//libera memoria alocada para os campos variaveis
        }
        
        //se nenhum registro foi encontrado, imprime a mensagem de erro
        if (achou == 0) {
            printf("Registro inexistente.\n\n");
        }
    }

    fclose(arquivo); 
}

int main(){
    //main que le a operacao a ser realizada e chama a funcao correspondente com os args necessarios
    char arg1[30], arg2[30];
    int op=0, n=0;

    scanf("%d", &op);
    scanf("%s", arg1);

    switch(op){
        case 1:
            scanf("%s", arg2);
            createTable(arg1, arg2);
            break;
        case 2:
            selectFrom(arg1);
            break;
        case 3:
            scanf("%d", &n);
            selectWhere(arg1, n);
            break;
        default:
            break;
    }

    return 0;
}
