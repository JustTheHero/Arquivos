#include "lista.h"

typedef struct no NO;
struct no{
    long int offset;
    int tamReg;
    NO *prox;
};

struct lista{
    NO *cabeca;
};

LISTA *criaLista(){
    LISTA *l = (LISTA*)malloc(sizeof(LISTA));
    if(l != NULL){
        l->cabeca = NULL;
    }
    return l;
}

void inicializaLista(LISTA *l, FILE *arqdados, long int offset){
    fseek(arqdados, 0, SEEK_SET);

    while(offset != -1){
        fseek(arqdados, offset, SEEK_SET);

        char removido;
        int tamanhoRegistro;
        long int prox;

        fread(&removido, sizeof(char), 1, arqdados);
        fread(&tamanhoRegistro, sizeof(int), 1, arqdados);
        fread(&prox, sizeof(long int), 1, arqdados);

        insereOrdenado(l, offset, tamanhoRegistro);
        offset = prox;
    }

}

void insereOrdenado(LISTA *l, long int offset, int tamReg){
    NO *novo = (NO*)malloc(sizeof(NO));
    if(novo != NULL){
        novo->offset = offset;
        novo->tamReg = tamReg;

        if(l->cabeca == NULL || l->cabeca->tamReg > tamReg){
            novo->prox = l->cabeca;
            l->cabeca = novo;
        }else{
            NO *atual = l->cabeca;
            while(atual->prox != NULL && atual->prox->tamReg < tamReg){
                atual = atual->prox;
            }
            novo->prox = atual->prox;
            atual->prox = novo;
        }
    }
}

void liberarLista(LISTA *l){
    NO *atual = l->cabeca;
    while(atual != NULL){
        NO *aux = atual->prox;
        free(atual);
        atual = aux;
    }
    free(l);
}

long int getOffsetProx(LISTA *l, long int offset){
    NO *atual = l->cabeca;
    while(atual != NULL && atual->offset != offset){
        atual = atual->prox;
    }
    if(atual != NULL && atual->prox != NULL){
        return atual->prox->offset;
    }
    return -1;
}

long int getTopo(LISTA *l){
    if(l->cabeca != NULL){
        return l->cabeca->offset;
    }
    return -1;
}