#ifndef LISTA_REMOVIDOS_H
#define LISTA_REMOVIDOS_H

#include<stdio.h>
#include<stdlib.h>

typedef struct lista LISTA;

LISTA *criaLista();
void inicializaLista(LISTA *l, FILE *arqdados, long int topo);
void insereOrdenado(LISTA *l, long int offset, int tamReg);
void liberarLista(LISTA *l);
long int getOffsetProx(LISTA *l, long int offset);
long int getTopo(LISTA *l);

#endif